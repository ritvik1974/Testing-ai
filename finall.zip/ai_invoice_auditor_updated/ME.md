# AI Invoice Auditor

See [README.md](./README.md) for the architecture, setup, data boundaries, and
verification instructions.
