# AI Invoice Auditor

The application accepts invoice PDFs, DOCX files, and PNG images, extracts invoice
data, checks it against the mock ERP, stores an auditable result, and provides a
human-review and question-answering interface.

## Architecture

Docker Compose runs exactly six services:

| Service | Responsibility | Persistent data |
| --- | --- | --- |
| `agent` | FastAPI, LangGraph processing, MCP tools, A2A endpoint, RAG, and report generation | Audit/checkpoint data in PostgreSQL; invoice files and reports in `./data` |
| `mock-erp` | HTTP API over the seeded ERP master data in PostgreSQL | ERP tables in PostgreSQL |
| `streamlit-ui` | Dashboard, upload, review, and assistant pages | Read-only access to the audit schema |
| `postgres` | Durable ERP, audit, feedback, and LangGraph checkpoint storage | `postgres_data` volume |
| `qdrant` | Rebuildable vector index for invoice evidence | `qdrant_data` volume |
| `redis` | Disposable cache | None; persistence is disabled |

PostgreSQL is the source of truth for audit records and workflow checkpoints.
Qdrant can be rebuilt from PostgreSQL; Redis is only a cache. Original invoice
files and generated reports live under the mounted `data` directory, not in the
database. The Streamlit service connects to PostgreSQL using the `invoice_reader`
role, which is granted `SELECT` access to the audit schema only. The agent
performs audit writes and accesses ERP records through the mock ERP HTTP API;
the mock ERP service owns ERP fixture seeding.

LangGraph coordinates document extraction, data validation, business/ERP
validation, reporting, and persistence. The agent's MCP client starts the
in-process stdio MCP server and discovers its tools dynamically; this does not add
a seventh Compose service. The agent also exposes an A2A agent card at
`/.well-known/agent-card.json` and a JSON-RPC endpoint at `/a2a`. The invoice
assistant uses Google ADK with LiteLLM when LLM mode is enabled. RAG uses Qdrant
retrieval and a LangGraph workflow with retrieval/generation checks.

## Requirements

- Docker Desktop with the Linux container engine enabled
- Docker Compose v2 or newer
- At least 4 GB of available memory recommended

## Configure and start

From the project root in PowerShell:

```powershell
Copy-Item .env.example .env
```

Edit `.env` and set two different local passwords:

- `POSTGRES_PASSWORD` for the application/database owner.
- `UI_DB_PASSWORD` for the read-only dashboard database role.

Use URL-safe characters for both passwords because the agent and ERP use
`POSTGRES_PASSWORD` in a PostgreSQL connection URL and Compose places
`UI_DB_PASSWORD` in the UI connection URL. Keep `.env` local; it is ignored by
Git.

For an offline/demo run, leave `LLM_ENABLED=false`. The application uses local
fallback behavior, does not call Bedrock, and does not machine-translate text.
To enable LLM translation, RAG generation, and the ADK assistant, set
`LLM_ENABLED=true` and provide valid AWS
Bedrock credentials/region and model access in `.env`. Langfuse tracing is
optional; set its keys if an account is configured.

Build and start all six services:

```powershell
docker compose up --build -d
docker compose ps
```

Open the UI at <http://localhost:8501>, the agent API at <http://localhost:8000>,
the API documentation at <http://localhost:8000/docs>, and the mock ERP at
<http://localhost:8001/docs>. The agent health endpoints are
`/health/live` and `/health/ready`.

The file watcher monitors `data/incoming`. Files uploaded through the UI are
placed in that same queue. Supported files are PDF, DOCX, and PNG, up to 25 MB.
Generated JSON/HTML reports are stored in `data/outputs/reports`.

## Data and persistence

- PostgreSQL initialization creates the `erp`, `audit`, and `langgraph` schemas.
- ERP fixture files in `data/ERP_mockdata` are seeded into PostgreSQL by the
  mock ERP service. The agent never reads ERP fixture files directly.
- The UI reads invoices, line items, current discrepancies, and feedback from
  PostgreSQL using its read-only role. Corrections are submitted to the agent,
  which appends feedback and revalidates the invoice.
- LangGraph checkpoints are stored in PostgreSQL so processing state survives
  agent restarts.
- Qdrant stores derived vectors and can be repopulated from audit records.
- Redis can be cleared or restarted without losing audit data.

Avoid `docker compose down -v` during normal operation: it deletes the
PostgreSQL and Qdrant volumes. To stop the containers while retaining data, use:

```powershell
docker compose down
```

For a clean, destructive local reset only when the stored data is disposable:

```powershell
docker compose down -v
docker compose up --build -d
```

## Verification checklist

After startup, verify:

1. `docker compose ps` shows all six services running and healthy.
2. `http://localhost:8000/health/ready` returns `{"status":"ready"}`.
3. `http://localhost:8001/health/ready` returns a healthy mock ERP response.
4. The UI loads, displays the invoice list, and accepts a supported invoice file.
5. Processing creates an audit record, line items, discrepancies, and a report as
   applicable; restart `agent` and confirm the audit remains available.
6. Submit a correction in the review page and confirm the feedback history is
   retained after a restart.

The container runtime must be available to execute this checklist. `docker
compose config` can validate the Compose configuration without starting
containers.
