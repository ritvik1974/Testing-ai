CREATE SCHEMA IF NOT EXISTS erp;
CREATE SCHEMA IF NOT EXISTS audit;
CREATE SCHEMA IF NOT EXISTS langgraph;

CREATE TABLE IF NOT EXISTS erp.vendors (
    vendor_id VARCHAR(64) PRIMARY KEY,
    vendor_name VARCHAR(255) NOT NULL,
    country VARCHAR(8),
    currency CHAR(3)
);

CREATE UNIQUE INDEX IF NOT EXISTS vendors_name_ci_idx
    ON erp.vendors (LOWER(vendor_name));

CREATE TABLE IF NOT EXISTS erp.sku_master (
    item_code VARCHAR(64) PRIMARY KEY,
    category VARCHAR(128),
    uom VARCHAR(32),
    gst_rate NUMERIC(6, 3) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS erp.purchase_orders (
    po_number VARCHAR(64) PRIMARY KEY,
    vendor_id VARCHAR(64) NOT NULL REFERENCES erp.vendors(vendor_id)
);

CREATE TABLE IF NOT EXISTS erp.po_line_items (
    id BIGSERIAL PRIMARY KEY,
    po_number VARCHAR(64) NOT NULL REFERENCES erp.purchase_orders(po_number) ON DELETE CASCADE,
    item_code VARCHAR(64) NOT NULL REFERENCES erp.sku_master(item_code),
    description TEXT,
    qty NUMERIC(12, 3) NOT NULL,
    unit_price NUMERIC(14, 4) NOT NULL,
    currency CHAR(3) NOT NULL,
    UNIQUE (po_number, item_code)
);

CREATE TABLE IF NOT EXISTS audit.invoice_audit (
    invoice_id UUID PRIMARY KEY,
    file_path VARCHAR(512) NOT NULL,
    file_checksum CHAR(64) NOT NULL UNIQUE,
    extraction_method VARCHAR(32),
    raw_extracted_text TEXT,
    translated_text TEXT,
    source_language VARCHAR(8),
    translation_confidence NUMERIC(4, 3),
    invoice_number VARCHAR(64),
    vendor_id VARCHAR(64),
    vendor_name VARCHAR(255),
    po_number VARCHAR(64),
    invoice_date DATE,
    currency CHAR(3),
    total_amount NUMERIC(14, 2),
    tax_amount NUMERIC(14, 2),
    validation_status VARCHAR(32) NOT NULL DEFAULT 'processing',
    recommendation VARCHAR(32) NOT NULL DEFAULT 'pending',
    extracted_raw JSONB NOT NULL DEFAULT '{}'::jsonb,
    current_data JSONB NOT NULL DEFAULT '{}'::jsonb,
    report JSONB NOT NULL DEFAULT '{}'::jsonb,
    thread_id VARCHAR(128),
    processing_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed_at TIMESTAMPTZ
);
ALTER TABLE audit.invoice_audit
    ADD COLUMN IF NOT EXISTS report JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS audit.invoice_line_items (
    id BIGSERIAL PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    item_code VARCHAR(64),
    description TEXT,
    quantity NUMERIC(12, 3),
    unit_price NUMERIC(14, 4),
    line_total NUMERIC(14, 2),
    UNIQUE (invoice_id, line_number)
);

CREATE TABLE IF NOT EXISTS audit.discrepancies (
    id BIGSERIAL PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id) ON DELETE CASCADE,
    field_name VARCHAR(128) NOT NULL,
    invoice_value TEXT,
    erp_value TEXT,
    deviation_pct NUMERIC(12, 4),
    severity VARCHAR(16) NOT NULL,
    is_current BOOLEAN NOT NULL DEFAULT TRUE,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE audit.discrepancies
    ADD COLUMN IF NOT EXISTS is_current BOOLEAN NOT NULL DEFAULT TRUE;

CREATE TABLE IF NOT EXISTS audit.human_feedback (
    id BIGSERIAL PRIMARY KEY,
    invoice_id UUID NOT NULL REFERENCES audit.invoice_audit(invoice_id),
    field_name VARCHAR(128) NOT NULL,
    original_value TEXT,
    corrected_value TEXT NOT NULL,
    corrected_by VARCHAR(128) NOT NULL,
    corrected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revalidated BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS invoice_audit_vendor_date_idx
    ON audit.invoice_audit (vendor_id, invoice_date DESC);
CREATE INDEX IF NOT EXISTS invoice_audit_status_idx
    ON audit.invoice_audit (validation_status, processed_at DESC);
CREATE INDEX IF NOT EXISTS invoice_line_items_invoice_idx
    ON audit.invoice_line_items (invoice_id, line_number);
CREATE INDEX IF NOT EXISTS discrepancies_invoice_idx
    ON audit.discrepancies (invoice_id, detected_at DESC);
CREATE INDEX IF NOT EXISTS human_feedback_invoice_idx
    ON audit.human_feedback (invoice_id, corrected_at DESC);
