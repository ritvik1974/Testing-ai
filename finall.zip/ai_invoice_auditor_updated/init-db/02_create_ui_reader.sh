#!/bin/sh
set -eu

psql \
  --username "$POSTGRES_USER" \
  --dbname "$POSTGRES_DB" \
  --set ON_ERROR_STOP=1 \
  --set reader_password="$UI_DB_PASSWORD" \
  --set postgres_user="$POSTGRES_USER" <<'SQL'
CREATE ROLE invoice_reader LOGIN PASSWORD :'reader_password';
GRANT USAGE ON SCHEMA audit TO invoice_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA audit TO invoice_reader;
ALTER DEFAULT PRIVILEGES FOR ROLE :"postgres_user" IN SCHEMA audit
    GRANT SELECT ON TABLES TO invoice_reader;
SQL
