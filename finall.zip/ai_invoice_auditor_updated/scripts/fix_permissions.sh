#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
chmod -R 755 "$ROOT_DIR"
find "$ROOT_DIR" -type f -name '*.sh' -exec chmod +x {} +
