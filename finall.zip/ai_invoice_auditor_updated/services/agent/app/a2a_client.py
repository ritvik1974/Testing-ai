from __future__ import annotations

import os
import uuid

import httpx


def generate_over_a2a(question: str, context: str) -> str:
    base_url = os.getenv("A2A_AGENT_URL", "http://127.0.0.1:8000").rstrip("/")
    payload = {
        "jsonrpc": "2.0",
        "id": str(uuid.uuid4()),
        "method": "message/send",
        "params": {
            "message": {
                "messageId": str(uuid.uuid4()),
                "role": "user",
                "parts": [
                    {
                        "kind": "text",
                        "text": (
                            f"Question:\n{question}\n\n"
                            f"Retrieved invoice evidence:\n{context}"
                        ),
                    }
                ],
            }
        },
    }
    try:
        response = httpx.post(f"{base_url}/a2a", json=payload, timeout=60)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        raise RuntimeError(f"A2A request to the ADK assistant failed: {exc}") from exc
    body = response.json()
    if "error" in body:
        raise RuntimeError(f"A2A assistant returned an error: {body['error']}")
    parts = body.get("result", {}).get("artifacts", [{}])[0].get("parts", [])
    answer = next(
        (part.get("text") for part in parts if part.get("kind") == "text"),
        None,
    )
    if not answer:
        raise RuntimeError("A2A assistant response contained no text")
    return answer
