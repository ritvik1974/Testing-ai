from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any

from app.config import rules
from app.mcp_client import call_tools


def _decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None
    return number if number.is_finite() else None


def _deviation(invoice_value: Decimal, erp_value: Decimal) -> Decimal:
    if erp_value == 0:
        return Decimal("0") if invoice_value == 0 else Decimal("100")
    return abs(invoice_value - erp_value) / abs(erp_value) * Decimal("100")


def _add(
    discrepancies: list[dict[str, Any]],
    field: str,
    invoice_value: Any,
    erp_value: Any,
    severity: str,
    deviation: Decimal | float = 0,
) -> None:
    discrepancies.append(
        {
            "field_name": field,
            "invoice_value": str(invoice_value),
            "erp_value": str(erp_value),
            "deviation_pct": round(float(deviation), 4),
            "severity": severity,
        }
    )


def run_business_validation(data: dict[str, Any]) -> list[dict[str, Any]]:
    config = rules()
    tolerances = config.get("tolerances", {})
    discrepancies: list[dict[str, Any]] = []
    calls: list[tuple[str, dict[str, Any]]] = []
    labels: list[tuple[str, Any]] = []

    vendor_id = data.get("vendor_id")
    vendor_name = data.get("vendor_name")
    if vendor_id:
        calls.append(("lookup_vendor", {"vendor_id": str(vendor_id)}))
        labels.append(("vendor", None))
    elif vendor_name:
        calls.append(("lookup_vendor_by_name", {"vendor_name": str(vendor_name)}))
        labels.append(("vendor", None))

    po_number = data.get("po_number")
    if po_number:
        calls.append(("lookup_purchase_order", {"po_number": str(po_number)}))
        labels.append(("po", None))
    else:
        _add(discrepancies, "po_number", "MISSING", "required for ERP validation", "HIGH")

    sku_codes = sorted(
        {
            str(item.get("item_code"))
            for item in data.get("line_items", [])
            if isinstance(item, dict) and item.get("item_code")
        }
    )
    for code in sku_codes:
        calls.append(("lookup_sku", {"item_code": code}))
        labels.append(("sku", code))

    results = call_tools(calls) if calls else []
    response_map: dict[tuple[str, Any], dict[str, Any]] = {}
    for label, result in zip(labels, results):
        response_map[label] = result or {"found": False}

    vendor = response_map.get(("vendor", None))
    if vendor is not None:
        if not vendor.get("found", True):
            _add(discrepancies, "vendor_id", vendor_id or vendor_name, "vendor not found", "CRITICAL")
        else:
            data["vendor_id"] = vendor.get("vendor_id") or vendor_id
            data["vendor_name"] = vendor.get("vendor_name") or vendor_name

    purchase_order = response_map.get(("po", None))
    if purchase_order is None:
        return discrepancies
    if not purchase_order.get("found", True):
        _add(discrepancies, "po_number", po_number, "purchase order not found", "CRITICAL")
        return discrepancies

    erp_vendor_id = str(purchase_order.get("vendor_id") or "")
    if data.get("vendor_id") and erp_vendor_id and str(data["vendor_id"]) != erp_vendor_id:
        _add(
            discrepancies,
            "vendor_id",
            data["vendor_id"],
            erp_vendor_id,
            "CRITICAL",
        )

    po_lines = {
        str(item.get("item_code", "")).upper(): item
        for item in purchase_order.get("line_items", [])
    }
    price_tolerance = Decimal(str(tolerances.get("price_difference_percent", 5)))
    quantity_tolerance = Decimal(str(tolerances.get("quantity_difference_percent", 0)))
    rounding = Decimal(str(tolerances.get("rounding_amount", 0.05)))
    expected_tax = Decimal("0")
    invoice_lines = data.get("line_items", [])

    for index, item in enumerate(invoice_lines, start=1):
        if not isinstance(item, dict):
            continue
        code = str(item.get("item_code") or "").upper()
        po_line = po_lines.get(code)
        if not po_line:
            _add(
                discrepancies,
                f"line_{index}.item_code",
                item.get("item_code"),
                "not present on purchase order",
                "HIGH",
            )
        else:
            for field, invoice_key, tolerance in (
                ("qty", "qty", quantity_tolerance),
                ("unit_price", "unit_price", price_tolerance),
            ):
                invoice_value = _decimal(item.get(invoice_key))
                erp_value = _decimal(po_line.get(field))
                if invoice_value is None or erp_value is None:
                    continue
                deviation = _deviation(invoice_value, erp_value)
                if deviation > tolerance:
                    _add(
                        discrepancies,
                        f"line_{index}.{field}",
                        invoice_value,
                        erp_value,
                        "HIGH",
                        deviation,
                    )

            invoice_currency = str(data.get("currency") or "").upper()
            erp_currency = str(po_line.get("currency") or "").upper()
            if invoice_currency and erp_currency and invoice_currency != erp_currency:
                _add(
                    discrepancies,
                    f"line_{index}.currency",
                    invoice_currency,
                    erp_currency,
                    "CRITICAL",
                )

        sku = response_map.get(("sku", str(item.get("item_code") or "")))
        line_total = _decimal(item.get("total"))
        if sku and sku.get("found", True) and line_total is not None:
            gst_rate = _decimal(sku.get("gst_rate")) or Decimal("0")
            expected_tax += line_total * gst_rate / Decimal("100")
        elif sku and not sku.get("found", True):
            _add(
                discrepancies,
                f"line_{index}.item_code",
                item.get("item_code"),
                "not present in SKU master",
                "HIGH",
            )

    stated_tax = _decimal(data.get("tax_amount"))
    if stated_tax is not None:
        tax_tolerance = Decimal(str(tolerances.get("tax_difference_percent", 2)))
        tax_deviation = _deviation(stated_tax, expected_tax)
        if abs(stated_tax - expected_tax) > rounding and tax_deviation > tax_tolerance:
            _add(
                discrepancies,
                "tax_amount",
                stated_tax,
                expected_tax,
                "HIGH",
                tax_deviation,
            )
    return discrepancies


def recommendation_for(
    data: dict[str, Any],
    discrepancies: list[dict[str, Any]],
) -> tuple[str, str]:
    critical = any(item.get("severity") == "CRITICAL" for item in discrepancies)
    if critical and str(data.get("currency") or "").upper() not in {
        str(value).upper() for value in rules().get("accepted_currencies", [])
    }:
        return "reject", "failed"
    if discrepancies:
        return "manual_review", "partial"
    threshold = float(
        rules()
        .get("validation_policies", {})
        .get("auto_approve_confidence_threshold", 0.95)
    )
    confidence = _decimal(data.get("translation_confidence")) or Decimal("0")
    if confidence < Decimal(str(threshold)):
        return "manual_review", "partial"
    return "approve", "passed"
