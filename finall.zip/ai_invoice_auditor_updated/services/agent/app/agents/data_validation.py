from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

from app.config import rules


def _number(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None
    return parsed if parsed.is_finite() else None


def _discrepancy(field: str, value: Any, expected: str, severity: str) -> dict[str, Any]:
    return {
        "field_name": field,
        "invoice_value": "MISSING" if value is None else str(value),
        "erp_value": expected,
        "deviation_pct": 0,
        "severity": severity,
    }


def validate_completeness(data: dict[str, Any]) -> list[dict[str, Any]]:
    config = rules()
    required = config.get("required_fields", {})
    discrepancies: list[dict[str, Any]] = []

    for field in required.get("header", []):
        value = data.get(field)
        if value is None or str(value).strip().lower() in {"", "none", "null", "n/a"}:
            discrepancies.append(
                _discrepancy(field, None, "required field", "CRITICAL")
            )

    raw_date = data.get("invoice_date")
    if raw_date:
        try:
            date.fromisoformat(str(raw_date))
        except ValueError:
            discrepancies.append(
                _discrepancy("invoice_date", raw_date, "ISO date YYYY-MM-DD", "HIGH")
            )

    accepted_currencies = {
        str(value).upper() for value in config.get("accepted_currencies", [])
    }
    currency = str(data.get("currency") or "").upper()
    if currency and currency not in accepted_currencies:
        discrepancies.append(
            _discrepancy(
                "currency",
                currency,
                f"one of {', '.join(sorted(accepted_currencies))}",
                "CRITICAL",
            )
        )

    lines = data.get("line_items")
    if not isinstance(lines, list) or not lines:
        discrepancies.append(
            _discrepancy("line_items", None, "at least one line item", "CRITICAL")
        )
        return discrepancies

    line_total_sum = Decimal("0")
    for index, item in enumerate(lines, start=1):
        if not isinstance(item, dict):
            discrepancies.append(
                _discrepancy(f"line_{index}", item, "line-item object", "HIGH")
            )
            continue
        prefix = f"line_{index}"
        for field in required.get("line_item", []):
            if item.get(field) in (None, ""):
                discrepancies.append(
                    _discrepancy(f"{prefix}.{field}", None, "required field", "HIGH")
                )

        quantity = _number(item.get("qty"))
        unit_price = _number(item.get("unit_price"))
        stated_total = _number(item.get("total"))
        if quantity is None:
            if item.get("qty") not in (None, ""):
                discrepancies.append(
                    _discrepancy(f"{prefix}.qty", item.get("qty"), "finite number", "HIGH")
                )
        if unit_price is None:
            if item.get("unit_price") not in (None, ""):
                discrepancies.append(
                    _discrepancy(
                        f"{prefix}.unit_price", item.get("unit_price"), "finite number", "HIGH"
                    )
                )
        if stated_total is None and item.get("total") not in (None, ""):
            discrepancies.append(
                _discrepancy(
                    f"{prefix}.total", item.get("total"), "finite number", "HIGH"
                )
            )
        if quantity is not None and unit_price is not None and stated_total is not None:
            calculated = quantity * unit_price
            rounding = Decimal(str(config.get("tolerances", {}).get("rounding_amount", 0.05)))
            if abs(calculated - stated_total) > rounding:
                deviation = (
                    abs(calculated - stated_total) / abs(calculated) * 100
                    if calculated
                    else Decimal("100")
                )
                discrepancies.append(
                    {
                        "field_name": f"{prefix}.total",
                        "invoice_value": str(stated_total),
                        "erp_value": str(calculated),
                        "deviation_pct": round(float(deviation), 4),
                        "severity": "HIGH",
                    }
                )
            line_total_sum += stated_total

    invoice_total = _number(data.get("total_amount"))
    tax = _number(data.get("tax_amount"))
    rounding = Decimal(str(config.get("tolerances", {}).get("rounding_amount", 0.05)))
    if invoice_total is not None:
        expected_totals = [line_total_sum]
        if tax is not None:
            expected_totals.append(line_total_sum + tax)
        if not any(abs(invoice_total - expected) <= rounding for expected in expected_totals):
            expected = " or ".join(str(value) for value in expected_totals)
            deviation = (
                abs(invoice_total - expected_totals[-1]) / abs(expected_totals[-1]) * 100
                if expected_totals[-1]
                else Decimal("100")
            )
            discrepancies.append(
                {
                    "field_name": "total_amount",
                    "invoice_value": str(invoice_total),
                    "erp_value": expected,
                    "deviation_pct": round(float(deviation), 4),
                    "severity": "HIGH",
                }
            )
    return discrepancies
