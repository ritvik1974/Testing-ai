from __future__ import annotations

import os
from pathlib import Path

import pdfplumber
import pytesseract
from docx import Document
from pdf2image import convert_from_path
from PIL import Image

SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".png"}
OCR_LANGUAGES = os.getenv("OCR_LANGUAGES", "eng+spa+deu")


def _extract_pdf_text(path: Path) -> str:
    with pdfplumber.open(path) as document:
        pages = [page.extract_text(layout=False) or "" for page in document.pages]
    return "\n\n".join(text for text in pages if text.strip())


def _ocr_pdf(path: Path) -> str:
    pages = convert_from_path(path, dpi=250, first_page=1, last_page=100)
    if not pages:
        raise ValueError(f"No pages could be rendered from {path.name}")
    return "\n\n".join(
        pytesseract.image_to_string(image, lang=OCR_LANGUAGES).strip()
        for image in pages
    )


def _extract_docx_text(path: Path) -> str:
    document = Document(path)
    content = [paragraph.text for paragraph in document.paragraphs if paragraph.text.strip()]
    for table in document.tables:
        for row in table.rows:
            values = [cell.text.strip() for cell in row.cells]
            if any(values):
                content.append(" | ".join(values))
    return "\n".join(content)


def extract_text(path: str | Path) -> tuple[str, str]:
    file_path = Path(path)
    extension = file_path.suffix.lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported invoice type: {extension or 'no extension'}")
    if not file_path.is_file():
        raise FileNotFoundError(f"Invoice file not found: {file_path}")

    if extension == ".pdf":
        text = _extract_pdf_text(file_path)
        if text.strip():
            return text, "pdfplumber"
        return _ocr_pdf(file_path), "tesseract"
    if extension == ".docx":
        return _extract_docx_text(file_path), "python-docx"
    with Image.open(file_path) as image:
        image.load()
        return pytesseract.image_to_string(image, lang=OCR_LANGUAGES), "tesseract"


def extract_text_from_path(path: str | Path) -> str:
    return extract_text(path)[0]
