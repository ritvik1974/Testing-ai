from __future__ import annotations

import hashlib
import logging
import os
import threading
from pathlib import Path

from app.agents.invoice_workflow import process_invoice
from app.audit_store import (
    DuplicateInvoice,
    recorded_status,
    record_processing_failure,
)

logger = logging.getLogger(__name__)
WATCH_DIR = Path(os.getenv("INCOMING_DIR", "/data/incoming"))
SUPPORTED = {".pdf", ".docx", ".png"}
POLL_SECONDS = 3


def checksum_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            digest.update(block)
    return digest.hexdigest()


def _stable(path: Path, previous: dict[str, tuple[int, int]]) -> bool:
    stat = path.stat()
    current = (stat.st_size, stat.st_mtime_ns)
    key = str(path.resolve())
    if previous.get(key) == current:
        return True
    previous[key] = current
    return False


def watch_incoming_folder(stop_event: threading.Event) -> None:
    logger.info("Monitoring incoming invoices at %s", WATCH_DIR)
    WATCH_DIR.mkdir(parents=True, exist_ok=True)
    observed: dict[str, tuple[int, int]] = {}
    while not stop_event.is_set():
        try:
            paths = sorted(WATCH_DIR.iterdir())
        except OSError:
            logger.exception("Unable to read incoming invoice directory %s", WATCH_DIR)
            stop_event.wait(POLL_SECONDS)
            continue
        for path in paths:
            if stop_event.is_set():
                break
            if not path.is_file() or path.name.endswith(".uploading"):
                continue
            if path.suffix.lower() not in SUPPORTED:
                continue
            try:
                if not _stable(path, observed):
                    continue
                checksum = checksum_file(path)
                status = recorded_status(checksum)
                if status and status != "processing":
                    continue
                logger.info("Processing invoice file %s", path.name)
                invoice_id = process_invoice(str(path), checksum)
                logger.info("Invoice %s processed as %s", path.name, invoice_id)
            except DuplicateInvoice:
                logger.info("Skipping duplicate invoice content in %s", path.name)
            except Exception as exc:
                logger.exception("Invoice processing failed for %s", path.name)
                try:
                    checksum = checksum_file(path)
                    record_processing_failure(
                        str(path),
                        checksum,
                        path.suffix.lower().lstrip("."),
                        str(exc),
                    )
                except Exception:
                    logger.exception(
                        "Unable to persist failed-file audit for %s",
                        path.name,
                    )
        stop_event.wait(POLL_SECONDS)
