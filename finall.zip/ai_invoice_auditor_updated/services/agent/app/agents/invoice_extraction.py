from __future__ import annotations

import json
import os
import re
from datetime import datetime
from string import Template
from typing import Any

import litellm

from app.cache import cached_llm_response
from app.config import prompts

_NUMBER = (
    r"[-+]?(?:\d{1,3}(?:[.,\s]\d{3})+(?:[.,]\d{1,4})?"
    r"|\d+(?:[.,]\d{1,4})?)"
)


def normalize_currency(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip().upper()
    symbol_map = {
        **prompts().get("currency_symbol_map", {}),
        "$": "USD",
        "€": "EUR",
        "₹": "INR",
        "£": "GBP",
    }
    if text in symbol_map:
        return symbol_map[text]
    return text if re.fullmatch(r"[A-Z]{3}", text) else None


def _parse_number(value: str | None) -> float | None:
    if not value:
        return None
    cleaned = re.sub(r"\s", "", value)
    if "," in cleaned and "." in cleaned:
        decimal_separator = "." if cleaned.rfind(".") > cleaned.rfind(",") else ","
        thousands_separator = "," if decimal_separator == "." else "."
        cleaned = cleaned.replace(thousands_separator, "")
        cleaned = cleaned.replace(decimal_separator, ".")
    elif "," in cleaned:
        suffix = cleaned.rsplit(",", 1)[-1]
        cleaned = cleaned.replace(",", "." if len(suffix) <= 2 else "")
    elif cleaned.count(".") > 1:
        parts = cleaned.split(".")
        cleaned = "".join(parts[:-1]) + "." + parts[-1]
    try:
        return float(cleaned)
    except ValueError:
        return None


def _invoice_date(raw_text: str) -> str | None:
    patterns = (
        r"(?:invoice\s+date|date)\s*[:#-]?\s*(\d{4}-\d{1,2}-\d{1,2})",
        r"(?:invoice\s+date|date)\s*[:#-]?\s*(\d{1,2}[./-]\d{1,2}[./-]\d{2,4})",
    )
    for pattern in patterns:
        match = re.search(pattern, raw_text, re.IGNORECASE)
        if not match:
            continue
        value = match.group(1)
        formats = ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d.%m.%Y", "%d-%m-%Y")
        for date_format in formats:
            try:
                return datetime.strptime(value, date_format).date().isoformat()
            except ValueError:
                continue
    return None


def extract_invoice_fields(raw_text: str) -> dict[str, Any]:
    invoice_no = re.search(
        r"(?:invoice\s*(?:no\.?|number|#)|inv(?:oice)?)\s*[:#-]?\s*([A-Z0-9][A-Z0-9_/-]+)",
        raw_text,
        re.IGNORECASE,
    )
    vendor_id = re.search(r"\bvendor\s*id\s*[:#-]?\s*([A-Z0-9_-]+)", raw_text, re.I)
    vendor_name = re.search(r"\bvendor\s*name\s*[:#-]?\s*([^\r\n]+)", raw_text, re.I)
    po_number = re.search(
        r"\b(?:purchase\s+order|p\.?\s*o\.?)\s*(?:no\.?|number|#)?\s*[:#-]?\s*([A-Z0-9_-]+)",
        raw_text,
        re.IGNORECASE,
    )
    currency_match = re.search(
        r"\b(?:currency|amount\s*currency)\s*[:#-]?\s*(USD|EUR|INR|GBP|CAD|AUD)\b",
        raw_text,
        re.IGNORECASE,
    )
    if currency_match is None:
        currency_match = re.search(r"([$€₹£])\s*" + _NUMBER, raw_text)
    total_match = re.search(
        r"\b(?:grand\s+total|total\s+amount|invoice\s+total|total)\s*[:#-]?\s*"
        r"(?:(?:USD|EUR|INR|GBP|CAD|AUD)\s*)?([$€₹£]?)\s*(" + _NUMBER + r")",
        raw_text,
        re.IGNORECASE,
    )
    tax_match = re.search(
        r"\b(?:tax|vat|gst)\s*(?:amount)?\s*[:#-]?\s*"
        r"(?:(?:USD|EUR|INR|GBP|CAD|AUD)\s*)?([$€₹£]?)\s*(" + _NUMBER + r")",
        raw_text,
        re.IGNORECASE,
    )

    lines: list[dict[str, Any]] = []
    line_pattern = re.compile(
        r"^\s*([A-Z]{2,}[A-Z0-9_-]*\d[A-Z0-9_-]*)\s+(.+?)\s+"
        r"(" + _NUMBER + r")\s+(" + _NUMBER + r")(?:\s+(" + _NUMBER + r"))?\s*$",
        re.MULTILINE | re.IGNORECASE,
    )
    for match in line_pattern.finditer(raw_text):
        item_code, description, quantity, unit_price, line_total = match.groups()
        qty = _parse_number(quantity)
        price = _parse_number(unit_price)
        lines.append(
            {
                "item_code": item_code,
                "description": description.strip(),
                "qty": qty,
                "unit_price": price,
                "total": _parse_number(line_total)
                if line_total
                else (round(qty * price, 2) if qty is not None and price is not None else None),
            }
        )

    vendor = vendor_name.group(1).strip() if vendor_name else None
    if vendor:
        vendor = re.split(r"\s{2,}|\s+(?:invoice|date|po)\s*[:#-]", vendor, maxsplit=1, flags=re.I)[0]
    return {
        "invoice_no": invoice_no.group(1).strip() if invoice_no else None,
        "invoice_date": _invoice_date(raw_text),
        "vendor_id": vendor_id.group(1).strip() if vendor_id else None,
        "vendor_name": vendor,
        "po_number": po_number.group(1).strip() if po_number else None,
        "currency": normalize_currency(
            currency_match.group(1) if currency_match and currency_match.lastindex == 1
            else (currency_match.group(1) if currency_match else total_match.group(1) if total_match else None)
        ),
        "total_amount": _parse_number(total_match.group(2)) if total_match else None,
        "tax_amount": _parse_number(tax_match.group(2)) if tax_match else None,
        "line_items": lines,
    }


def _completion(prompt: str, model: str) -> str:
    response = litellm.completion(
        model=model,
        messages=[
            {"role": "system", "content": prompts()["personas"]["invoice_auditor"]},
            {"role": "user", "content": prompt},
        ],
        temperature=0,
        aws_region_name=os.getenv("AWS_DEFAULT_REGION", "us-east-1"),
    )
    content = response.choices[0].message.content
    if not content:
        raise RuntimeError("Bedrock returned an empty invoice extraction response")
    return content


def _extract_with_llm(raw_text: str) -> dict[str, Any]:
    model = os.getenv(
        "BEDROCK_MODEL_TRANSLATE",
        "bedrock/us.cohere.command-r-plus-v1:0",
    )
    template = Template(prompts()["templates"]["invoice_extraction"])
    prompt = template.substitute(raw_text=raw_text[:50000])
    response = cached_llm_response(
        prompt,
        model,
        lambda: _completion(prompt, model),
    )
    start, end = response.find("{"), response.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("Bedrock response did not contain a JSON invoice")
    data = json.loads(response[start : end + 1])
    if not isinstance(data, dict) or not isinstance(data.get("line_items", []), list):
        raise ValueError("Bedrock response has an invalid invoice structure")
    confidence = float(data.get("translation_confidence", 0))
    if not 0 <= confidence <= 1:
        raise ValueError("Translation confidence must be between 0 and 1")
    data["translation_confidence"] = confidence
    data.setdefault("source_language", "unknown")
    data.setdefault("translated_text", "")
    data.setdefault("line_items", [])
    for item in data["line_items"]:
        if not isinstance(item, dict):
            raise ValueError("Bedrock returned a line item that is not an object")
    return data


def extract_invoice(raw_text: str) -> dict[str, Any]:
    if not raw_text.strip():
        raise ValueError("Cannot extract an invoice from empty text")
    if os.getenv("LLM_ENABLED", "false").strip().lower() == "true":
        return _extract_with_llm(raw_text)

    data = extract_invoice_fields(raw_text)
    return {
        **data,
        "source_language": "en",
        "translation_confidence": 0.0,
        "translated_text": raw_text,
        "translation_note": "LLM_ENABLED=false; text is retained without machine translation.",
    }
