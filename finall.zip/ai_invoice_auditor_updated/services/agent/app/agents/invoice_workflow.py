from __future__ import annotations

import logging
from typing import Any, TypedDict

from langgraph.graph import END, StateGraph

from app.agents.document_extraction import extract_text
from app.agents.invoice_extraction import extract_invoice
from app.audit_store import (
    DuplicateInvoice,
    get_invoice_by_checksum,
    insert_processing_record,
    recorded_status,
    save_extracted_text,
    save_result,
)
from app.observability import workflow_event
from app.rag.indexer import index_invoice
from app.reporting import build_report, write_reports
from app.validation import run_validations

logger = logging.getLogger(__name__)
_workflow = None


class InvoiceState(TypedDict, total=False):
    file_path: str
    checksum: str
    invoice_id: str
    raw_text: str
    extraction_method: str
    data: dict[str, Any]
    discrepancies: list[dict[str, Any]]
    recommendation: str
    validation_status: str
    report: dict[str, Any]
    report_paths: tuple[str, str]
    indexed_chunks: int


def extraction_node(state: InvoiceState) -> dict[str, Any]:
    if state.get("raw_text"):
        return {}
    raw_text, method = extract_text(state["file_path"])
    invoice_id = state.get("invoice_id")
    if invoice_id:
        save_extracted_text(
            invoice_id,
            state["file_path"],
            state["checksum"],
            method,
            raw_text,
        )
    else:
        invoice_id = insert_processing_record(
            state["file_path"],
            state["checksum"],
            method,
            raw_text,
        )
    workflow_event(
        invoice_id,
        "document_extracted",
        {"method": method, "characters": len(raw_text)},
    )
    return {
        "invoice_id": invoice_id,
        "raw_text": raw_text,
        "extraction_method": method,
    }


def translation_node(state: InvoiceState) -> dict[str, Any]:
    data = extract_invoice(state["raw_text"])
    workflow_event(
        state["invoice_id"],
        "invoice_translated_and_parsed",
        {
            "source_language": data.get("source_language"),
            "translation_confidence": data.get("translation_confidence"),
        },
    )
    return {"data": data}


def validation_node(state: InvoiceState) -> dict[str, Any]:
    discrepancies, recommendation, status = run_validations(state["data"])
    workflow_event(
        state["invoice_id"],
        "invoice_validated",
        {
            "discrepancy_count": len(discrepancies),
            "recommendation": recommendation,
            "status": status,
        },
    )
    return {
        "data": state["data"],
        "discrepancies": discrepancies,
        "recommendation": recommendation,
        "validation_status": status,
    }


def reporting_node(state: InvoiceState) -> dict[str, Any]:
    save_result(
        state["invoice_id"],
        state["data"],
        state["discrepancies"],
        state["recommendation"],
        state["validation_status"],
        initial=True,
    )
    report = build_report(
        state["invoice_id"],
        state["data"],
        state["discrepancies"],
        state["recommendation"],
        state["validation_status"],
    )
    paths = write_reports(report)
    workflow_event(
        state["invoice_id"],
        "report_persisted",
        {"json_report": paths[0], "html_report": paths[1]},
    )
    return {"report": report, "report_paths": paths}


def indexing_node(state: InvoiceState) -> dict[str, int]:
    count = index_invoice(
        state["invoice_id"],
        state["raw_text"],
        state["data"],
        state["report"],
    )
    workflow_event(
        state["invoice_id"],
        "rag_indexed",
        {"chunk_count": count},
    )
    return {"indexed_chunks": count}


def build_invoice_graph(checkpointer=None):
    graph = StateGraph(InvoiceState)
    graph.add_node("extract", extraction_node)
    graph.add_node("translate_and_parse", translation_node)
    graph.add_node("validate", validation_node)
    graph.add_node("report", reporting_node)
    graph.add_node("index", indexing_node)
    graph.set_entry_point("extract")
    graph.add_edge("extract", "translate_and_parse")
    graph.add_edge("translate_and_parse", "validate")
    graph.add_edge("validate", "report")
    graph.add_edge("report", "index")
    graph.add_edge("index", END)
    return graph.compile(checkpointer=checkpointer)


def set_checkpointer(checkpointer=None) -> None:
    global _workflow
    _workflow = build_invoice_graph(checkpointer)


def process_invoice(file_path: str, checksum: str) -> str:
    status = recorded_status(checksum)
    if status and status != "processing":
        raise DuplicateInvoice(f"Invoice content is already recorded with status {status}")
    existing = get_invoice_by_checksum(checksum) if status == "processing" else None
    state: InvoiceState = {
        "file_path": file_path,
        "checksum": checksum,
    }
    if existing is not None:
        state["invoice_id"] = str(existing["invoice_id"])
        if existing.get("raw_extracted_text"):
            state["raw_text"] = existing["raw_extracted_text"]
            state["extraction_method"] = existing.get("extraction_method") or "stored"

    graph = _workflow or build_invoice_graph()
    try:
        result = graph.invoke(
            state,
            config={
                "configurable": {
                    "thread_id": checksum,
                }
            },
        )
    except Exception:
        logger.exception("Invoice workflow failed for %s", file_path)
        raise
    invoice_id = result.get("invoice_id")
    if not invoice_id:
        raise RuntimeError("Invoice workflow completed without an audit record ID")
    return str(invoice_id)


def run_invoice_workflow(raw_text: str) -> dict[str, Any]:
    data = extract_invoice(raw_text)
    discrepancies, recommendation, status = run_validations(data)
    return {
        **data,
        "discrepancies": discrepancies,
        "recommendation": recommendation,
        "validation_status": status,
    }
