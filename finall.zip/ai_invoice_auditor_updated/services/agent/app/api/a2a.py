from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from app.agents.adk_agent import run_adk_answer
from app.rai import validate_user_question

router = APIRouter()


@router.get("/.well-known/agent-card.json")
def agent_card(request: Request) -> dict[str, Any]:
    base_url = str(request.base_url).rstrip("/")
    return {
        "name": "AI Invoice Evidence Assistant",
        "description": "Google ADK invoice assistant exposed for A2A discovery and invocation.",
        "url": f"{base_url}/a2a",
        "version": "1.0.0",
        "capabilities": {
            "streaming": False,
            "pushNotifications": False,
            "stateTransitionHistory": False,
        },
        "defaultInputModes": ["text/plain"],
        "defaultOutputModes": ["text/plain"],
        "skills": [
            {
                "id": "grounded-invoice-answer",
                "name": "Grounded invoice answer",
                "description": "Answers an invoice question from caller-supplied audit evidence.",
                "tags": ["invoice", "audit", "rag"],
                "examples": ["Why was invoice INV-EN-001 flagged?"],
            }
        ],
    }


def _message_text(message: dict[str, Any]) -> str:
    parts = message.get("parts", [])
    return "\n".join(
        str(part.get("text", ""))
        for part in parts
        if part.get("kind", part.get("type")) == "text" and part.get("text")
    )


@router.post("/a2a")
async def a2a_message(payload: dict[str, Any]) -> dict[str, Any]:
    if payload.get("jsonrpc") != "2.0" or payload.get("method") != "message/send":
        raise HTTPException(status_code=400, detail="Unsupported A2A JSON-RPC request")
    request_id = payload.get("id")
    params = payload.get("params")
    message = params.get("message") if isinstance(params, dict) else None
    if not isinstance(message, dict):
        raise HTTPException(status_code=400, detail="A2A request must include params.message")
    text = _message_text(message)
    if not text.strip():
        raise HTTPException(status_code=400, detail="A2A message must contain text")

    marker = "\n\nRetrieved invoice evidence:\n"
    if marker not in text:
        raise HTTPException(
            status_code=400,
            detail="A2A assistant requires a question and retrieved invoice evidence",
        )
    question, evidence = text.split(marker, maxsplit=1)
    question = question.removeprefix("Question:\n")
    try:
        validate_user_question(question)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    if os.getenv("LLM_ENABLED", "false").strip().lower() != "true":
        answer = f"From the indexed invoice evidence for your question: {evidence[:700]}"
    else:
        answer = await run_adk_answer(question, evidence)

    now = datetime.now(timezone.utc).isoformat()
    task_id = str(uuid.uuid4())
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "id": task_id,
            "contextId": message.get("contextId") or str(uuid.uuid4()),
            "status": {"state": "completed", "timestamp": now},
            "artifacts": [
                {
                    "artifactId": str(uuid.uuid4()),
                    "name": "invoice-answer",
                    "parts": [{"kind": "text", "text": answer}],
                }
            ],
        },
    }
