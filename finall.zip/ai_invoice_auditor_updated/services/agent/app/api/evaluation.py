from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from ragas_evaluation.run import evaluate

router = APIRouter()


@router.post("/evaluation/rag")
def evaluate_rag() -> dict[str, Any]:
    return evaluate()
