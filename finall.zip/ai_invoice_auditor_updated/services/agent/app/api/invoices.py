from __future__ import annotations

import hashlib
import re
import uuid
from pathlib import Path
from typing import Any
from uuid import UUID

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel, Field

from app.agents.invoice_workflow import run_invoice_workflow
from app.audit_store import (
    get_invoice,
    get_invoice_by_checksum,
    list_feedback,
    list_invoices,
)
from app.config import DATA_DIR
from app.revalidation import revalidate
from app.validation import validate_invoice

router = APIRouter()
SUPPORTED_FILES = {".pdf", ".docx", ".png"}
MAX_UPLOAD_BYTES = 25 * 1024 * 1024


class ExtractRequest(BaseModel):
    raw_text: str = Field(min_length=1, max_length=50000)


class CorrectionRequest(BaseModel):
    field: str = Field(min_length=1, max_length=128)
    corrected_value: str = Field(max_length=1000)
    corrected_by: str = Field(min_length=1, max_length=128)


@router.get("/invoices")
def get_invoices(limit: int = 200) -> list[dict[str, Any]]:
    return list_invoices(max(1, min(limit, 500)))


@router.post("/invoices/upload", status_code=202)
def upload_invoice(file: UploadFile = File(...)) -> dict[str, Any]:
    original_name = Path(file.filename or "invoice").name
    extension = Path(original_name).suffix.lower()
    if extension not in SUPPORTED_FILES:
        raise HTTPException(
            status_code=415,
            detail="Only PDF, DOCX, and PNG invoice files are supported",
        )
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", original_name).strip("._")
    if not safe_name:
        raise HTTPException(status_code=400, detail="Uploaded filename is invalid")

    incoming_dir = DATA_DIR / "incoming"
    incoming_dir.mkdir(parents=True, exist_ok=True)
    target = incoming_dir / f"{uuid.uuid4().hex[:12]}-{safe_name}"
    temporary = target.with_name(target.name + ".uploading")
    total = 0
    digest = hashlib.sha256()
    try:
        with temporary.open("wb") as destination:
            while True:
                block = file.file.read(1024 * 1024)
                if not block:
                    break
                total += len(block)
                if total > MAX_UPLOAD_BYTES:
                    raise HTTPException(
                        status_code=413,
                        detail="Invoice upload exceeds the 25 MB limit",
                    )
                digest.update(block)
                destination.write(block)
            destination.flush()
        checksum = digest.hexdigest()
        existing = get_invoice_by_checksum(checksum)
        if existing:
            temporary.unlink(missing_ok=True)
            return {
                "status": "duplicate",
                "invoice_id": str(existing["invoice_id"]),
                "validation_status": existing["validation_status"],
            }
        temporary.replace(target)
    except HTTPException:
        temporary.unlink(missing_ok=True)
        raise
    except OSError as exc:
        temporary.unlink(missing_ok=True)
        raise HTTPException(status_code=500, detail="Unable to save invoice upload") from exc
    finally:
        file.file.close()
    return {
        "status": "queued",
        "filename": target.name,
        "size_bytes": total,
        "checksum": checksum,
    }


@router.post("/invoices/extract")
def extract_invoice(payload: ExtractRequest) -> dict[str, Any]:
    invoice = run_invoice_workflow(payload.raw_text)
    validation = validate_invoice(invoice)
    return {"invoice": invoice, "validation": validation}


@router.get("/invoices/{invoice_id}")
def get_invoice_by_id(invoice_id: UUID) -> dict[str, Any]:
    record = get_invoice(str(invoice_id))
    if record is None:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return record


@router.post("/invoices/{invoice_id}/corrections")
def correct_invoice(
    invoice_id: UUID,
    request: CorrectionRequest,
) -> dict[str, Any]:
    try:
        return revalidate(
            str(invoice_id),
            request.field,
            request.corrected_value,
            request.corrected_by,
        )
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/invoices/{invoice_id}/feedback")
def get_invoice_feedback(invoice_id: UUID) -> list[dict[str, Any]]:
    if get_invoice(str(invoice_id)) is None:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return list_feedback(str(invoice_id))
