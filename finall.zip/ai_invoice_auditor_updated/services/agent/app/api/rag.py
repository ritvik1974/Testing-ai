from __future__ import annotations

from typing import Any
from uuid import UUID

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.rai import validate_user_question
from app.rag.graph import answer_question

router = APIRouter()


class RAGRequest(BaseModel):
    question: str = Field(min_length=1, max_length=4000)
    invoice_id: UUID | None = None


@router.post("/rag/query")
def rag_query(request: RAGRequest) -> dict[str, Any]:
    try:
        validate_user_question(request.question)
        return answer_question(
            request.question,
            str(request.invoice_id) if request.invoice_id else None,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
