from __future__ import annotations

import uuid
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

from psycopg.types.json import Jsonb

from app.db import connect


class DuplicateInvoice(RuntimeError):
    pass


def _decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None
    return number if number.is_finite() else None


def _date(value: Any) -> date | None:
    if value in (None, ""):
        return None
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        return None


def insert_processing_record(
    file_path: str,
    checksum: str,
    method: str,
    raw_text: str,
) -> str:
    invoice_id = str(uuid.uuid4())
    with connect() as connection:
        row = connection.execute(
            """
            INSERT INTO audit.invoice_audit
                (invoice_id, file_path, file_checksum, extraction_method, raw_extracted_text, thread_id)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (file_checksum) DO NOTHING
            RETURNING invoice_id
            """,
            (invoice_id, file_path, checksum, method, raw_text, invoice_id),
        ).fetchone()
    if row is None:
        raise DuplicateInvoice(f"Invoice content with checksum {checksum} is already recorded")
    return str(row["invoice_id"])


def recorded_status(checksum: str) -> str | None:
    with connect() as connection:
        row = connection.execute(
            "SELECT validation_status FROM audit.invoice_audit WHERE file_checksum = %s",
            (checksum,),
        ).fetchone()
    return row["validation_status"] if row else None


def get_invoice_by_checksum(checksum: str) -> dict[str, Any] | None:
    rows = _invoice_query("WHERE a.file_checksum = %s", (checksum,), limit=1)
    return rows[0] if rows else None


def save_extracted_text(
    invoice_id: str,
    file_path: str,
    checksum: str,
    method: str,
    raw_text: str,
) -> None:
    with connect() as connection:
        row = connection.execute(
            """
            UPDATE audit.invoice_audit SET
                file_path = %s,
                extraction_method = %s,
                raw_extracted_text = %s
            WHERE invoice_id = %s AND file_checksum = %s
            """,
            (file_path, method, raw_text, invoice_id, checksum),
        )
    if row.rowcount != 1:
        raise LookupError(f"Audit record {invoice_id} does not match the file checksum")


def record_processing_failure(
    file_path: str,
    checksum: str,
    method: str,
    error: str,
) -> str:
    invoice_id = str(uuid.uuid4())
    with connect() as connection:
        row = connection.execute(
            """
            INSERT INTO audit.invoice_audit
                (invoice_id, file_path, file_checksum, extraction_method,
                 validation_status, recommendation, processing_error, processed_at)
            VALUES (%s, %s, %s, %s, 'failed', 'manual_review', %s, NOW())
            ON CONFLICT (file_checksum) DO UPDATE SET
                validation_status = 'failed',
                recommendation = 'manual_review',
                processing_error = EXCLUDED.processing_error,
                processed_at = NOW()
            RETURNING invoice_id
            """,
            (invoice_id, file_path, checksum, method, error[:4000]),
        ).fetchone()
    return str(row["invoice_id"])


def save_result(
    invoice_id: str,
    data: dict[str, Any],
    discrepancies: list[dict[str, Any]],
    recommendation: str,
    status: str,
    *,
    initial: bool,
    feedback: tuple[str, str | None, str, str] | None = None,
) -> None:
    invoice_number = data.get("invoice_no") or data.get("invoice_number")
    with connect() as connection:
        with connection.transaction():
            if initial:
                updated = connection.execute(
                    """
                    UPDATE audit.invoice_audit SET
                        translated_text = %s,
                        source_language = %s,
                        translation_confidence = %s,
                        invoice_number = %s,
                        vendor_id = %s,
                        vendor_name = %s,
                        po_number = %s,
                        invoice_date = %s,
                        currency = %s,
                        total_amount = %s,
                        tax_amount = %s,
                        extracted_raw = %s,
                        current_data = %s,
                        validation_status = %s,
                        recommendation = %s,
                        processing_error = NULL,
                        processed_at = NOW()
                    WHERE invoice_id = %s
                    """,
                    (
                        data.get("translated_text"),
                        data.get("source_language"),
                        _decimal(data.get("translation_confidence")),
                        invoice_number,
                        data.get("vendor_id"),
                        data.get("vendor_name"),
                        data.get("po_number"),
                        _date(data.get("invoice_date")),
                        data.get("currency"),
                        _decimal(data.get("total_amount")),
                        _decimal(data.get("tax_amount")),
                        Jsonb(data),
                        Jsonb(data),
                        status,
                        recommendation,
                        invoice_id,
                    ),
                )
            else:
                updated = connection.execute(
                    """
                    UPDATE audit.invoice_audit SET
                        invoice_number = %s,
                        vendor_id = %s,
                        vendor_name = %s,
                        po_number = %s,
                        invoice_date = %s,
                        currency = %s,
                        total_amount = %s,
                        tax_amount = %s,
                        current_data = %s,
                        validation_status = %s,
                        recommendation = %s,
                        processed_at = NOW()
                    WHERE invoice_id = %s
                    """,
                    (
                        invoice_number,
                        data.get("vendor_id"),
                        data.get("vendor_name"),
                        data.get("po_number"),
                        _date(data.get("invoice_date")),
                        data.get("currency"),
                        _decimal(data.get("total_amount")),
                        _decimal(data.get("tax_amount")),
                        Jsonb(data),
                        status,
                        recommendation,
                        invoice_id,
                    ),
                )
            if updated.rowcount != 1:
                raise LookupError(f"Audit record {invoice_id} does not exist")

            connection.execute(
                "DELETE FROM audit.invoice_line_items WHERE invoice_id = %s",
                (invoice_id,),
            )
            for line_number, item in enumerate(data.get("line_items") or [], start=1):
                if not isinstance(item, dict):
                    continue
                connection.execute(
                    """
                    INSERT INTO audit.invoice_line_items
                        (invoice_id, line_number, item_code, description, quantity, unit_price, line_total)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        invoice_id,
                        line_number,
                        item.get("item_code"),
                        item.get("description"),
                        _decimal(item.get("qty")),
                        _decimal(item.get("unit_price")),
                        _decimal(item.get("total")),
                    ),
                )

            connection.execute(
                "UPDATE audit.discrepancies SET is_current = FALSE WHERE invoice_id = %s AND is_current",
                (invoice_id,),
            )
            for item in discrepancies:
                connection.execute(
                    """
                    INSERT INTO audit.discrepancies
                        (invoice_id, field_name, invoice_value, erp_value, deviation_pct, severity)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (
                        invoice_id,
                        item["field_name"],
                        str(item.get("invoice_value", "")),
                        str(item.get("erp_value", "")),
                        _decimal(item.get("deviation_pct", 0)),
                        item.get("severity", "MEDIUM"),
                    ),
                )
            if feedback is not None:
                field, original, corrected, author = feedback
                connection.execute(
                    """
                    INSERT INTO audit.human_feedback
                        (invoice_id, field_name, original_value, corrected_value, corrected_by, revalidated)
                    VALUES (%s, %s, %s, %s, %s, TRUE)
                    """,
                    (invoice_id, field, original, corrected, author),
                )


def save_report(invoice_id: str, report: dict[str, Any]) -> None:
    with connect() as connection:
        row = connection.execute(
            "UPDATE audit.invoice_audit SET report = %s WHERE invoice_id = %s",
            (Jsonb(report), invoice_id),
        )
    if row.rowcount != 1:
        raise LookupError(f"Audit record {invoice_id} does not exist")


def _invoice_query(
    where_clause: str = "",
    parameters: tuple[Any, ...] = (),
    limit: int = 200,
) -> list[dict[str, Any]]:
    query = f"""
        SELECT a.*,
            COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'item_code', l.item_code,
                    'description', l.description,
                    'qty', l.quantity,
                    'unit_price', l.unit_price,
                    'total', l.line_total
                ) ORDER BY l.line_number)
                FROM audit.invoice_line_items l
                WHERE l.invoice_id = a.invoice_id
            ), '[]'::jsonb) AS line_items,
            COALESCE((
                SELECT jsonb_agg(jsonb_build_object(
                    'field_name', d.field_name,
                    'invoice_value', d.invoice_value,
                    'erp_value', d.erp_value,
                    'deviation_pct', d.deviation_pct,
                    'severity', d.severity,
                    'detected_at', d.detected_at
                ) ORDER BY d.id)
                FROM audit.discrepancies d
                WHERE d.invoice_id = a.invoice_id AND d.is_current
            ), '[]'::jsonb) AS discrepancies
        FROM audit.invoice_audit a
        {where_clause}
        ORDER BY a.created_at DESC
        LIMIT %s
    """
    with connect() as connection:
        rows = connection.execute(query, (*parameters, limit)).fetchall()
    return [dict(row) for row in rows]


def list_invoices(limit: int = 200) -> list[dict[str, Any]]:
    return _invoice_query(limit=limit)


def get_invoice(invoice_id: str) -> dict[str, Any] | None:
    rows = _invoice_query("WHERE a.invoice_id = %s", (invoice_id,), limit=1)
    return rows[0] if rows else None


def find_invoice_by_number(invoice_number: str) -> dict[str, Any] | None:
    rows = _invoice_query(
        "WHERE a.invoice_number = %s",
        (invoice_number,),
        limit=1,
    )
    return rows[0] if rows else None


def list_feedback(invoice_id: str) -> list[dict[str, Any]]:
    with connect() as connection:
        rows = connection.execute(
            """
            SELECT field_name, original_value, corrected_value, corrected_by,
                   corrected_at, revalidated
            FROM audit.human_feedback
            WHERE invoice_id = %s
            ORDER BY corrected_at
            """,
            (invoice_id,),
        ).fetchall()
    return [dict(row) for row in rows]


def load_index_records() -> list[dict[str, Any]]:
    with connect() as connection:
        rows = connection.execute(
            """
            SELECT invoice_id, invoice_number, vendor_id, vendor_name,
                   source_language, raw_extracted_text, current_data,
                   validation_status, recommendation
            FROM audit.invoice_audit
            WHERE validation_status <> 'failed' AND raw_extracted_text IS NOT NULL
            ORDER BY created_at
            """
        ).fetchall()
    return [dict(row) for row in rows]
