from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Callable
from typing import Any

import redis

_client: redis.Redis | None = None


def initialize_cache() -> redis.Redis:
    global _client
    _client = redis.Redis.from_url(
        os.environ["REDIS_URL"],
        decode_responses=True,
        socket_connect_timeout=3,
        socket_timeout=3,
    )
    _client.ping()
    return _client


def cache_client() -> redis.Redis:
    if _client is None:
        raise RuntimeError("Redis cache has not been initialized")
    return _client


def cached_llm_response(
    prompt: str,
    model: str,
    loader: Callable[[], str],
    *,
    ttl_seconds: int = 3600,
) -> str:
    cache_key = "llm:" + hashlib.sha256(
        f"{model}\0{prompt}".encode("utf-8")
    ).hexdigest()
    cached = cache_client().get(cache_key)
    if cached:
        return cached
    response = loader()
    if not isinstance(response, str) or not response.strip():
        raise RuntimeError("LLM returned an empty response")
    cache_client().setex(cache_key, ttl_seconds, response)
    return response


def json_cache_get(key: str) -> Any | None:
    value = cache_client().get(key)
    return json.loads(value) if value else None


def json_cache_set(key: str, value: Any, ttl_seconds: int = 300) -> None:
    cache_client().setex(key, ttl_seconds, json.dumps(value, default=str))


def cache_ready() -> bool:
    return bool(cache_client().ping())
