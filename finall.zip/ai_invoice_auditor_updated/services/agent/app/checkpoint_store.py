from __future__ import annotations

import os

from langgraph.checkpoint.postgres import PostgresSaver
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool


def _configure(connection) -> None:
    connection.execute("SET search_path TO langgraph, public")


def initialize_checkpointer() -> tuple[ConnectionPool, PostgresSaver]:
    pool = ConnectionPool(
        conninfo=os.environ["DATABASE_URL"],
        min_size=1,
        max_size=8,
        kwargs={"autocommit": True, "row_factory": dict_row},
        configure=_configure,
        open=False,
    )
    pool.open(wait=True, timeout=30)
    saver = PostgresSaver(pool)
    saver.setup()
    return pool, saver
