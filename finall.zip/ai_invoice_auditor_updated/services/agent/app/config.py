from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

APP_ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", "/data")).resolve()
CONFIG_DIR = Path(
    os.getenv("CONFIG_DIR", APP_ROOT.parent.parent.parent / "config")
).resolve()
RULES_PATH = CONFIG_DIR / "rules.yaml"
PROMPTS_PATH = CONFIG_DIR / "prompts.yaml"


def load_yaml(path: str | Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as source:
        value = yaml.safe_load(source) or {}
    if not isinstance(value, dict):
        raise ValueError(f"Configuration at {path} must contain a YAML mapping")
    return value


def rules() -> dict[str, Any]:
    return load_yaml(RULES_PATH)


def prompts() -> dict[str, Any]:
    return load_yaml(PROMPTS_PATH)


RULES = rules()
PROMPTS = prompts()
