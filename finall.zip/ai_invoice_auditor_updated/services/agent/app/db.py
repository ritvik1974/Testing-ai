from __future__ import annotations

import os
import time
from collections.abc import Generator
from contextlib import contextmanager

import psycopg
from psycopg.rows import dict_row

DATABASE_URL = os.environ["DATABASE_URL"]


def connect() -> psycopg.Connection:
    return psycopg.connect(
        DATABASE_URL,
        row_factory=dict_row,
        connect_timeout=5,
    )


def wait_for_database(timeout_seconds: int = 60) -> None:
    deadline = time.monotonic() + timeout_seconds
    last_error: psycopg.Error | None = None
    while time.monotonic() < deadline:
        try:
            with connect() as connection:
                connection.execute("SELECT 1")
            return
        except psycopg.Error as exc:
            last_error = exc
            time.sleep(1)
    raise RuntimeError("PostgreSQL did not become ready before the startup deadline") from last_error


@contextmanager
def transaction() -> Generator[psycopg.Connection, None, None]:
    with connect() as connection:
        with connection.transaction():
            yield connection
