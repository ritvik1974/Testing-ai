from __future__ import annotations

import os
from urllib.parse import quote

import httpx

ERP_BASE_URL = os.getenv("ERP_BASE_URL", "http://mock-erp:8000").rstrip("/")


class ERPClient:
    def __init__(self, base_url: str | None = None, timeout: float = 10.0) -> None:
        self.base_url = (base_url or ERP_BASE_URL).rstrip("/")
        self.timeout = timeout

    def _get(self, path: str) -> dict | None:
        try:
            response = httpx.get(f"{self.base_url}{path}", timeout=self.timeout)
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Mock ERP request failed for {path}: {exc}") from exc

    def get_vendor(self, vendor_id: str) -> dict | None:
        return self._get(f"/vendor/{quote(vendor_id, safe='')}")

    def get_vendor_by_name(self, vendor_name: str) -> dict | None:
        return self._get(f"/vendor/name/{quote(vendor_name, safe='')}")

    def get_po(self, po_number: str) -> dict | None:
        return self._get(f"/po/{quote(po_number, safe='')}")

    def get_sku(self, item_code: str) -> dict | None:
        return self._get(f"/sku/{quote(item_code, safe='')}")

    def health(self) -> bool:
        try:
            response = httpx.get(f"{self.base_url}/health/ready", timeout=3)
            return response.status_code == 200
        except httpx.HTTPError:
            return False
