from __future__ import annotations

import logging
import os
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI

from app.agents.incoming_monitor import watch_incoming_folder
from app.api.a2a import router as a2a_router
from app.api.evaluation import router as evaluation_router
from app.api.health import router as health_router
from app.api.invoices import router as invoices_router
from app.api.rag import router as rag_router
from app.audit_store import list_invoices
from app.cache import cache_ready, initialize_cache
from app.checkpoint_store import initialize_checkpointer
from app.db import wait_for_database
from app.erp_client import ERPClient
from app.observability import flush_observability, initialize_observability
from app.rag.graph import set_checkpointer as set_rag_checkpointer
from app.rag.indexer import initialize_collection, sync_missing_index
from app.agents.invoice_workflow import set_checkpointer as set_invoice_checkpointer

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_: FastAPI):
    Path(os.getenv("INCOMING_DIR", "/data/incoming")).mkdir(parents=True, exist_ok=True)
    Path(os.getenv("REPORT_DIR", "/data/outputs/reports")).mkdir(parents=True, exist_ok=True)

    wait_for_database()
    initialize_cache()
    initialize_collection()
    pool, checkpointer = initialize_checkpointer()
    set_invoice_checkpointer(checkpointer)
    set_rag_checkpointer(checkpointer)
    initialize_observability()
    rebuilt = sync_missing_index()
    logger.info("Startup complete; indexed %s missing RAG chunks", rebuilt)

    stop_event = threading.Event()
    monitor = threading.Thread(
        target=watch_incoming_folder,
        args=(stop_event,),
        name="incoming-invoice-monitor",
        daemon=True,
    )
    monitor.start()
    try:
        yield
    finally:
        stop_event.set()
        monitor.join(timeout=10)
        flush_observability()
        pool.close()


app = FastAPI(title="AI Invoice Auditor", version="2.0.0", lifespan=lifespan)
app.include_router(health_router)
app.include_router(invoices_router, prefix="/api")
app.include_router(rag_router, prefix="/api")
app.include_router(evaluation_router, prefix="/api")
app.include_router(a2a_router)


@app.get("/")
def root() -> dict[str, str]:
    return {
        "message": "AI Invoice Auditor is running.",
        "docs": "/docs",
        "agent_card": "/.well-known/agent-card.json",
    }


@app.get("/api/dashboard")
def dashboard() -> dict:
    invoices = list_invoices()
    return {
        "total": len(invoices),
        "approved": sum(row.get("recommendation") == "approve" for row in invoices),
        "manual_review": sum(
            row.get("recommendation") == "manual_review" for row in invoices
        ),
        "rejected": sum(row.get("recommendation") == "reject" for row in invoices),
        "failed": sum(row.get("validation_status") == "failed" for row in invoices),
    }


@app.get("/health/ready")
def readiness() -> dict[str, str]:
    from app.db import connect
    from app.rag.indexer import qdrant_client

    with connect() as connection:
        connection.execute("SELECT 1")
    cache_ready()
    qdrant_client().get_collections()
    if not ERPClient().health():
        raise RuntimeError("Mock ERP is not ready")
    return {"status": "ready"}
