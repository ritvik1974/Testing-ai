from __future__ import annotations

import asyncio
import json
import os
import sys
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def _discover_and_call_many(
    calls: list[tuple[str, dict[str, Any]]],
) -> list[Any]:
    server = StdioServerParameters(
        command=sys.executable,
        args=["-m", "app.tools.mcp_server"],
        env=os.environ.copy(),
    )
    async with stdio_client(server) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            available = await session.list_tools()
            available_names = {tool.name for tool in available.tools}
            values = []
            for tool_name, arguments in calls:
                if tool_name not in available_names:
                    raise LookupError(f"MCP tool {tool_name!r} is not registered")
                result = await session.call_tool(tool_name, arguments)
                if result.isError:
                    messages = [
                        item.text
                        for item in result.content
                        if getattr(item, "text", None)
                    ]
                    raise RuntimeError(
                        f"MCP tool {tool_name!r} failed: {'; '.join(messages)}"
                    )
                text = next(
                    (
                        item.text
                        for item in result.content
                        if getattr(item, "text", None)
                    ),
                    None,
                )
                values.append(json.loads(text) if text else None)
            return values


def call_tool(tool_name: str, **arguments: Any) -> Any:
    return asyncio.run(_discover_and_call_many([(tool_name, arguments)]))[0]


def call_tools(
    calls: list[tuple[str, dict[str, Any]]],
) -> list[Any]:
    return asyncio.run(_discover_and_call_many(calls))
