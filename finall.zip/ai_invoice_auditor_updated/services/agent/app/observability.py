from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)
_client = None


def initialize_observability():
    global _client
    public_key = os.getenv("LANGFUSE_PUBLIC_KEY", "").strip()
    secret_key = os.getenv("LANGFUSE_SECRET_KEY", "").strip()
    if not public_key and not secret_key:
        logger.info("Langfuse tracing disabled; no credentials configured")
        return None
    if not public_key or not secret_key:
        raise RuntimeError("Both Langfuse public and secret keys must be configured")
    from langfuse import Langfuse

    _client = Langfuse(
        public_key=public_key,
        secret_key=secret_key,
        host=os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com"),
    )
    return _client


def workflow_event(
    trace_id: str | None,
    name: str,
    metadata: dict[str, Any] | None = None,
) -> None:
    safe_metadata = metadata or {}
    if _client is None:
        logger.info("workflow_event=%s metadata=%s", name, safe_metadata)
        return
    trace = _client.trace(
        id=trace_id,
        name="invoice-audit",
        metadata={"invoice_id": trace_id} if trace_id else {},
    )
    trace.event(name=name, metadata=safe_metadata)


def flush_observability() -> None:
    if _client is not None:
        _client.flush()
