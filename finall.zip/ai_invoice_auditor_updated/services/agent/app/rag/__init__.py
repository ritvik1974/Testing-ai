"""RAG utilities for invoice auditor."""
