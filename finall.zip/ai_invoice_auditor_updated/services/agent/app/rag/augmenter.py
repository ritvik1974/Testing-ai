from __future__ import annotations

import re
from typing import Any

_STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "did", "do", "for", "from",
    "how", "i", "in", "is", "it", "me", "of", "on", "or", "the", "this", "to",
    "was", "what", "when", "where", "which", "who", "why", "with",
}


def _terms(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[\w.-]+", text.casefold())
        if token not in _STOP_WORDS and len(token) > 1
    }


def augment(
    query: str,
    chunks: list[dict[str, Any]],
    max_chunks: int = 5,
) -> tuple[list[str], str]:
    query_terms = _terms(query)
    ranked = []
    for chunk in chunks:
        text = str(chunk.get("text", ""))
        chunk_terms = _terms(text)
        overlap = len(query_terms & chunk_terms) / max(1, len(query_terms))
        combined = 0.75 * float(chunk.get("score", 0)) + 0.25 * overlap
        ranked.append((combined, text))
    selected = [text for _, text in sorted(ranked, reverse=True)[:max_chunks]]
    return selected, "\n\n".join(selected)
