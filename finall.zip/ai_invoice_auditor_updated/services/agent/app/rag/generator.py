from __future__ import annotations

import os

from app.a2a_client import generate_over_a2a


def generate(query: str, context: str) -> str:
    if not context.strip():
        return ""
    if os.getenv("LLM_ENABLED", "false").strip().lower() != "true":
        return f"From the indexed invoice evidence for your question: {context[:700]}"
    return generate_over_a2a(query, context)
