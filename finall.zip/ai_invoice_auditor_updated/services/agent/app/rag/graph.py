from __future__ import annotations

import re
import uuid
from typing import Any, TypedDict

from langgraph.graph import END, StateGraph

from app.audit_store import find_invoice_by_number, get_invoice
from app.rag.augmenter import augment
from app.rag.generator import generate
from app.rag.indexer import sync_missing_index
from app.rag.reflector import reflect
from app.rag.retriever import retrieve

PASS_THRESHOLD = 0.7
MAX_RETRIES = 3
INITIAL_RETRIEVAL_LIMIT = 6
_graph = None


class RAGState(TypedDict, total=False):
    query: str
    invoice_id: str | None
    chunks: list[dict[str, Any]]
    selected_context: list[str]
    context: str
    answer: str
    triad: dict[str, float]
    attempt: int
    limit: int


def retrieval_node(state: RAGState) -> dict[str, Any]:
    chunks = retrieve(state["query"], state.get("invoice_id"), state["limit"])
    return {
        "chunks": chunks,
        "attempt": state["attempt"] + 1,
        "limit": state["limit"] + 4,
    }


def augmentation_node(state: RAGState) -> dict[str, Any]:
    selected, context = augment(state["query"], state["chunks"])
    return {"selected_context": selected, "context": context}


def generation_node(state: RAGState) -> dict[str, str]:
    return {"answer": generate(state["query"], state["context"])}


def reflection_node(state: RAGState) -> dict[str, dict[str, float]]:
    return {
        "triad": reflect(
            state["query"],
            state["context"],
            state["answer"],
        )
    }


def route_after_reflection(state: RAGState) -> str:
    if not state["chunks"]:
        return "done"
    if state["triad"]["average_score"] > PASS_THRESHOLD:
        return "done"
    if state["attempt"] >= MAX_RETRIES + 1:
        return "done"
    return "retrieve"


def build_rag_graph(checkpointer=None):
    graph = StateGraph(RAGState)
    graph.add_node("retrieve", retrieval_node)
    graph.add_node("augment", augmentation_node)
    graph.add_node("generate", generation_node)
    graph.add_node("reflect", reflection_node)
    graph.set_entry_point("retrieve")
    graph.add_edge("retrieve", "augment")
    graph.add_edge("augment", "generate")
    graph.add_edge("generate", "reflect")
    graph.add_conditional_edges(
        "reflect",
        route_after_reflection,
        {"retrieve": "retrieve", "done": END},
    )
    return graph.compile(checkpointer=checkpointer)


def set_checkpointer(checkpointer=None) -> None:
    global _graph
    _graph = build_rag_graph(checkpointer)


def _initial_state(query: str, invoice_id: str | None = None) -> RAGState:
    return {
        "query": query,
        "invoice_id": invoice_id,
        "chunks": [],
        "selected_context": [],
        "context": "",
        "answer": "",
        "triad": {},
        "attempt": 0,
        "limit": INITIAL_RETRIEVAL_LIMIT,
    }


def _structured_answer(
    query: str,
    invoice_id: str | None,
) -> dict[str, Any] | None:
    match = re.search(r"\bINV[-_/A-Z0-9]+\b", query, re.IGNORECASE)
    structured_terms = {
        "status",
        "recommendation",
        "total",
        "amount",
        "date",
        "vendor",
        "purchase",
        "order",
        "currency",
        "discrepancy",
        "discrepancies",
        "line",
        "quantity",
    }
    query_terms = set(re.findall(r"[a-z]+", query.casefold()))
    if not (invoice_id or match) or not (
        match or structured_terms.intersection(query_terms)
    ):
        return None
    record = get_invoice(invoice_id) if invoice_id else None
    if record is None and match:
        record = find_invoice_by_number(match.group(0))
        if record is None:
            return {
                "passed": False,
                "answer": "",
                "message": f"No audit record was found for invoice {match.group(0)}.",
                "contexts": [],
                "triad": {},
                "source": "postgresql",
            }
    if record is None:
        return None

    data = record.get("current_data") or {}
    summary = {
        "invoice_number": record.get("invoice_number"),
        "vendor": record.get("vendor_name") or record.get("vendor_id"),
        "purchase_order": record.get("po_number"),
        "invoice_date": record.get("invoice_date"),
        "currency": record.get("currency"),
        "total_amount": record.get("total_amount"),
        "validation_status": record.get("validation_status"),
        "recommendation": record.get("recommendation"),
        "discrepancies": record.get("discrepancies") or [],
        "line_items": record.get("line_items") or data.get("line_items", []),
    }
    return {
        "passed": True,
        "answer": "Invoice audit data: " + str(summary),
        "message": None,
        "contexts": ["PostgreSQL audit record: " + str(summary)],
        "triad": {
            "context_relevance": 1.0,
            "groundedness": 1.0,
            "answer_relevance": 1.0,
            "average_score": 1.0,
        },
        "source": "postgresql",
    }


def run_candidate(query: str, invoice_id: str | None = None) -> dict[str, Any]:
    sync_missing_index()
    state = _initial_state(query, invoice_id)
    graph = _graph or build_rag_graph()
    result = graph.invoke(
        state,
        config={"configurable": {"thread_id": str(uuid.uuid4())}},
    )
    triad = result.get("triad", {})
    passed = bool(result.get("answer")) and triad.get("average_score", 0) > PASS_THRESHOLD
    return {
        "query": query,
        "answer": result.get("answer", "") if passed else "",
        "passed": passed,
        "message": None
        if passed
        else "The answer did not meet the evidence confidence threshold. Please refine the question or select an invoice.",
        "contexts": result.get("selected_context", []),
        "triad": triad,
        "source": "qdrant",
        "attempts": result.get("attempt", 0),
    }


def answer_question(query: str, invoice_id: str | None = None) -> dict[str, Any]:
    if not query.strip():
        return {
            "passed": False,
            "answer": "",
            "message": "Enter an invoice-related question.",
            "contexts": [],
            "triad": {},
            "source": "none",
        }
    structured = _structured_answer(query, invoice_id)
    if structured is not None:
        return structured
    return run_candidate(query, invoice_id)
