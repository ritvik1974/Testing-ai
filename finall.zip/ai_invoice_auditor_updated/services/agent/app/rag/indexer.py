from __future__ import annotations

import hashlib
import os
import re
import uuid
from typing import Any

import litellm
from qdrant_client import QdrantClient, models

from app.audit_store import load_index_records
from app.cache import cache_client

COLLECTION = os.getenv("QDRANT_COLLECTION", "invoice_audits")
VECTOR_SIZE = 1024
_client: QdrantClient | None = None


def qdrant_client() -> QdrantClient:
    global _client
    if _client is None:
        _client = QdrantClient(url=os.getenv("QDRANT_URL", "http://qdrant:6333"), timeout=5)
    return _client


def initialize_collection() -> None:
    client = qdrant_client()
    if not client.collection_exists(COLLECTION):
        client.create_collection(
            collection_name=COLLECTION,
            vectors_config=models.VectorParams(
                size=VECTOR_SIZE,
                distance=models.Distance.COSINE,
            ),
        )
    client.get_collection(COLLECTION)


def _local_embedding(text: str) -> list[float]:
    vector = [0.0] * VECTOR_SIZE
    tokens = re.findall(r"[\w.-]+", text.casefold())
    features = tokens + [
        f"{tokens[index]} {tokens[index + 1]}"
        for index in range(len(tokens) - 1)
    ]
    for token in features:
        digest = hashlib.sha256(token.encode("utf-8")).digest()
        index = int.from_bytes(digest[:4], "big") % VECTOR_SIZE
        sign = 1.0 if digest[4] & 1 else -1.0
        vector[index] += sign
    norm = sum(value * value for value in vector) ** 0.5
    return [value / norm for value in vector] if norm else vector


def embed_text(text: str) -> list[float]:
    cache_key = "embedding:" + hashlib.sha256(text.encode("utf-8")).hexdigest()
    cached = cache_client().get(cache_key)
    if cached:
        return [float(value) for value in cached.split(",")]
    if os.getenv("LLM_ENABLED", "false").strip().lower() == "true":
        response = litellm.embedding(
            model=os.getenv(
                "BEDROCK_MODEL_EMBEDDING",
                "bedrock/amazon.titan-embed-text-v2:0",
            ),
            input=[text],
            aws_region_name=os.getenv("AWS_DEFAULT_REGION", "us-east-1"),
        )
        vector = [float(value) for value in response.data[0]["embedding"]]
        if len(vector) != VECTOR_SIZE:
            raise ValueError(
                f"Embedding model returned {len(vector)} values; Qdrant collection expects {VECTOR_SIZE}"
            )
    else:
        vector = _local_embedding(text)
    cache_client().setex(cache_key, 86400, ",".join(str(value) for value in vector))
    return vector


def _chunks(text: str, max_chars: int = 900, overlap: int = 120) -> list[str]:
    normalized = " ".join(text.split())
    if not normalized:
        return []
    chunks = []
    start = 0
    while start < len(normalized):
        end = min(start + max_chars, len(normalized))
        if end < len(normalized):
            boundary = normalized.rfind(" ", start, end)
            if boundary > start:
                end = boundary
        chunk = normalized[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(normalized):
            break
        start = max(start + 1, end - overlap)
    return chunks


def index_invoice(
    invoice_id: str,
    raw_text: str,
    data: dict[str, Any],
    report: dict[str, Any],
) -> int:
    initialize_collection()
    client = qdrant_client()
    client.delete(
        collection_name=COLLECTION,
        points_selector=models.FilterSelector(
            filter=models.Filter(
                must=[
                    models.FieldCondition(
                        key="invoice_id",
                        match=models.MatchValue(value=invoice_id),
                    )
                ]
            )
        ),
        wait=True,
    )
    documents = [
        ("invoice", raw_text),
        ("report", str(report.get("discrepancies", []))),
    ]
    points = []
    for source_type, document in documents:
        for chunk_text in _chunks(document):
            points.append(
                models.PointStruct(
                    id=str(uuid.uuid4()),
                    vector=embed_text(chunk_text),
                    payload={
                        "invoice_id": invoice_id,
                        "chunk_text": chunk_text,
                        "source_type": source_type,
                        "vendor": data.get("vendor_name") or data.get("vendor_id") or "",
                        "language": data.get("source_language") or "unknown",
                    },
                )
            )
    if points:
        client.upsert(collection_name=COLLECTION, points=points, wait=True)
    return len(points)


def _indexed_invoice_ids() -> set[str]:
    client = qdrant_client()
    known: set[str] = set()
    offset = None
    while True:
        points, offset = client.scroll(
            collection_name=COLLECTION,
            limit=256,
            offset=offset,
            with_payload=["invoice_id"],
            with_vectors=False,
        )
        known.update(
            str(point.payload["invoice_id"])
            for point in points
            if point.payload and point.payload.get("invoice_id")
        )
        if offset is None:
            return known


def sync_missing_index() -> int:
    initialize_collection()
    indexed = _indexed_invoice_ids()
    added = 0
    for record in load_index_records():
        invoice_id = str(record["invoice_id"])
        if invoice_id in indexed:
            continue
        raw_data = record.get("current_data") or {}
        report = record.get("report") or {}
        added += index_invoice(
            invoice_id,
            record.get("raw_extracted_text") or "",
            raw_data,
            report,
        )
        indexed.add(invoice_id)
    return added
