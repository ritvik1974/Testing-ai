from __future__ import annotations

import json
import os
import re
from typing import Any

import litellm
from string import Template

from app.cache import cached_llm_response
from app.config import prompts

_STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "did", "do", "for", "from",
    "how", "i", "in", "is", "it", "me", "of", "on", "or", "the", "this", "to",
    "was", "what", "when", "where", "which", "who", "why", "with",
}


def _words(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[\w.-]+", text.casefold())
        if token not in _STOP_WORDS and len(token) > 1
    }


def _local_score(query: str, context: str, answer: str) -> dict[str, float]:
    q, c, a = _words(query), _words(context), _words(answer)
    context_relevance = len(q & c) / max(1, len(q))
    groundedness = len(a & c) / max(1, len(a))
    answer_relevance = len(q & a) / max(1, len(q))
    dimensions = [
        max(0.0, min(1.0, context_relevance)),
        max(0.0, min(1.0, groundedness)),
        max(0.0, min(1.0, answer_relevance)),
    ]
    return {
        "context_relevance": round(dimensions[0], 4),
        "groundedness": round(dimensions[1], 4),
        "answer_relevance": round(dimensions[2], 4),
        "average_score": round(sum(dimensions) / 3, 4),
    }


def reflect(query: str, context: str, answer: str) -> dict[str, float]:
    if not context.strip() or not answer.strip():
        return {
            "context_relevance": 0.0,
            "groundedness": 0.0,
            "answer_relevance": 0.0,
            "average_score": 0.0,
        }
    if os.getenv("LLM_ENABLED", "false").strip().lower() != "true":
        return _local_score(query, context, answer)

    template = Template(prompts()["templates"]["rag_triad"])
    prompt = template.substitute(
        query=query[:3000],
        context=context[:9000],
        answer=answer[:5000],
    )
    model = os.getenv(
        "BEDROCK_MODEL_REASONING",
        "bedrock/us.amazon.nova-lite-v1:0",
    )

    def call() -> str:
        response = litellm.completion(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "Evaluate evidence quality honestly. Return only valid JSON.",
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0,
            aws_region_name=os.getenv("AWS_DEFAULT_REGION", "us-east-1"),
        )
        content = response.choices[0].message.content
        if not content:
            raise RuntimeError("Bedrock returned an empty RAG reflection")
        return content

    result = cached_llm_response(prompt, model, call)
    start, end = result.find("{"), result.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("RAG reflection response was not JSON")
    parsed: dict[str, Any] = json.loads(result[start : end + 1])
    keys = ("context_relevance", "groundedness", "answer_relevance")
    scores = [float(parsed[key]) for key in keys]
    if any(not 0 <= score <= 1 for score in scores):
        raise ValueError("RAG Triad scores must be between 0 and 1")
    return {
        **{key: round(score, 4) for key, score in zip(keys, scores)},
        "average_score": round(sum(scores) / len(scores), 4),
    }
