from __future__ import annotations

from typing import Any

from qdrant_client import models

from app.rag.indexer import COLLECTION, embed_text, initialize_collection, qdrant_client


def retrieve(
    query: str,
    invoice_id: str | None = None,
    limit: int = 6,
) -> list[dict[str, Any]]:
    initialize_collection()
    filters = None
    if invoice_id:
        filters = models.Filter(
            must=[
                models.FieldCondition(
                    key="invoice_id",
                    match=models.MatchValue(value=invoice_id),
                )
            ]
        )
    result = qdrant_client().query_points(
        collection_name=COLLECTION,
        query=embed_text(query),
        query_filter=filters,
        limit=max(1, min(limit, 50)),
        with_payload=True,
    )
    return [
        {
            "text": point.payload.get("chunk_text", ""),
            "invoice_id": point.payload.get("invoice_id"),
            "source_type": point.payload.get("source_type"),
            "vendor": point.payload.get("vendor"),
            "language": point.payload.get("language"),
            "score": float(point.score),
        }
        for point in result.points
        if point.payload and point.payload.get("chunk_text")
    ]
