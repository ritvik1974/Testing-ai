from __future__ import annotations

import json
import os
import tempfile
from html import escape
from pathlib import Path
from typing import Any

from app.audit_store import save_report


def build_report(
    invoice_id: str,
    data: dict[str, Any],
    discrepancies: list[dict[str, Any]],
    recommendation: str,
    validation_status: str,
) -> dict[str, Any]:
    missing_fields = [
        item["field_name"]
        for item in discrepancies
        if str(item.get("invoice_value", "")).upper() == "MISSING"
    ]
    return {
        "invoice_id": invoice_id,
        "invoice": data,
        "validation_status": validation_status,
        "recommendation": recommendation,
        "translation_confidence": data.get("translation_confidence"),
        "missing_fields": missing_fields,
        "discrepancy_summary": {
            "count": len(discrepancies),
            "by_severity": {
                severity: sum(
                    1 for item in discrepancies if item.get("severity") == severity
                )
                for severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW")
            },
        },
        "discrepancies": discrepancies,
    }


def _render_html(report: dict[str, Any]) -> str:
    invoice = report["invoice"]
    discrepancy_rows = "".join(
        "<tr>"
        f"<td>{escape(str(item.get('field_name', '')))}</td>"
        f"<td>{escape(str(item.get('invoice_value', '')))}</td>"
        f"<td>{escape(str(item.get('erp_value', '')))}</td>"
        f"<td>{escape(str(item.get('deviation_pct', '')))}%</td>"
        f"<td>{escape(str(item.get('severity', '')))}</td>"
        "</tr>"
        for item in report["discrepancies"]
    )
    line_rows = "".join(
        "<tr>"
        f"<td>{escape(str(item.get('item_code') or ''))}</td>"
        f"<td>{escape(str(item.get('description') or ''))}</td>"
        f"<td>{escape(str(item.get('qty') if item.get('qty') is not None else ''))}</td>"
        f"<td>{escape(str(item.get('unit_price') if item.get('unit_price') is not None else ''))}</td>"
        f"<td>{escape(str(item.get('total') if item.get('total') is not None else ''))}</td>"
        "</tr>"
        for item in invoice.get("line_items", [])
    )
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Invoice audit {escape(str(invoice.get('invoice_no') or report['invoice_id']))}</title>
  <style>
    body {{ font: 16px/1.5 system-ui, sans-serif; margin: 2rem auto; max-width: 1100px; padding: 0 1rem; color: #17212b; }}
    table {{ border-collapse: collapse; width: 100%; margin: 1rem 0 2rem; }}
    th, td {{ border: 1px solid #d6dde4; padding: .55rem; text-align: left; }}
    th {{ background: #edf3f7; }}
    .status {{ font-weight: 700; }}
  </style>
</head>
<body>
  <h1>Invoice audit report</h1>
  <p><strong>Invoice:</strong> {escape(str(invoice.get('invoice_no') or 'Not identified'))}</p>
  <p><strong>Vendor:</strong> {escape(str(invoice.get('vendor_name') or invoice.get('vendor_id') or 'Not identified'))}</p>
  <p><strong>PO:</strong> {escape(str(invoice.get('po_number') or 'Not identified'))}</p>
  <p><strong>Total:</strong> {escape(str(invoice.get('total_amount') if invoice.get('total_amount') is not None else 'Not identified'))} {escape(str(invoice.get('currency') or ''))}</p>
  <p><strong>Status:</strong> <span class="status">{escape(str(report['validation_status']))}</span></p>
  <p><strong>Recommendation:</strong> {escape(str(report['recommendation']))}</p>
  <p><strong>Translation confidence:</strong> {escape(str(report.get('translation_confidence') if report.get('translation_confidence') is not None else 'Not available'))}</p>
  <h2>Line items</h2>
  <table><thead><tr><th>Item</th><th>Description</th><th>Quantity</th><th>Unit price</th><th>Total</th></tr></thead><tbody>{line_rows}</tbody></table>
  <h2>Discrepancies ({len(report['discrepancies'])})</h2>
  <table><thead><tr><th>Field</th><th>Invoice value</th><th>ERP / expected</th><th>Deviation</th><th>Severity</th></tr></thead><tbody>{discrepancy_rows}</tbody></table>
  <h2>Missing fields</h2>
  <ul>{''.join(f'<li>{escape(field)}</li>' for field in report['missing_fields']) or '<li>None</li>'}</ul>
</body>
</html>
"""


def _atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        delete=False,
        suffix=".tmp",
    ) as temporary:
        temporary.write(content)
        temporary.flush()
        os.fsync(temporary.fileno())
        temporary_path = Path(temporary.name)
    temporary_path.replace(path)


def write_reports(report: dict[str, Any]) -> tuple[str, str]:
    output_dir = Path(os.getenv("REPORT_DIR", "/data/outputs/reports"))
    invoice_id = str(report["invoice_id"])
    json_path = output_dir / f"{invoice_id}.json"
    html_path = output_dir / f"{invoice_id}.html"
    _atomic_write(
        json_path,
        json.dumps(report, ensure_ascii=False, indent=2, default=str),
    )
    _atomic_write(html_path, _render_html(report))
    save_report(invoice_id, report)
    return str(json_path), str(html_path)
