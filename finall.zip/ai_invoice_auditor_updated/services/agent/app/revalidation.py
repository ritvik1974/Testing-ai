from __future__ import annotations

import copy
import math
import re
from typing import Any

from app.audit_store import get_invoice, list_feedback, save_result
from app.rag.indexer import index_invoice
from app.reporting import build_report, write_reports
from app.validation import run_validations

HEADER_FIELDS = {
    "invoice_no",
    "invoice_number",
    "invoice_date",
    "vendor_id",
    "vendor_name",
    "po_number",
    "currency",
    "total_amount",
    "tax_amount",
}
LINE_FIELD = re.compile(
    r"^(?:line_(\d+)|([A-Za-z0-9_-]+))\."
    r"(item_code|description|qty|quantity|unit_price|price|total|line_total)$"
)


def _number(value: str) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("Numeric correction must be a valid number") from exc
    if not math.isfinite(parsed):
        raise ValueError("Numeric correction must be finite")
    return parsed


def _target(attribute: str) -> str:
    return {
        "quantity": "qty",
        "price": "unit_price",
        "line_total": "total",
    }.get(attribute, attribute)


def _matching_line(data: dict[str, Any], index: str | None, code: str | None):
    for position, item in enumerate(data.get("line_items") or [], start=1):
        if not isinstance(item, dict):
            continue
        if (index and int(index) == position) or (
            code and str(item.get("item_code", "")).casefold() == code.casefold()
        ):
            return item
    return None


def _current_value(data: dict[str, Any], field: str) -> Any:
    if field in {"invoice_no", "invoice_number"}:
        return data.get("invoice_no") or data.get("invoice_number")
    if field in HEADER_FIELDS:
        return data.get(field)
    match = LINE_FIELD.fullmatch(field)
    if not match:
        return None
    index, code, attribute = match.groups()
    item = _matching_line(data, index, code)
    return item.get(_target(attribute)) if item else None


def _apply_one(data: dict[str, Any], field: str, value: str) -> None:
    if field in HEADER_FIELDS:
        target = "invoice_no" if field == "invoice_number" else field
        if target in {"total_amount", "tax_amount"}:
            data[target] = _number(value)
        else:
            data[target] = value.strip()
        if target == "invoice_no":
            data["invoice_number"] = value.strip()
        return

    match = LINE_FIELD.fullmatch(field)
    if not match:
        raise ValueError("Correction field is not supported")
    index, code, attribute = match.groups()
    item = _matching_line(data, index, code)
    if item is None:
        raise ValueError("The specified invoice line item was not found")
    target = _target(attribute)
    if target in {"qty", "unit_price", "total"}:
        item[target] = _number(value)
    else:
        item[target] = value.strip()
    if target in {"qty", "unit_price"}:
        quantity = _number(str(item.get("qty", 0)))
        unit_price = _number(str(item.get("unit_price", 0)))
        item["total"] = round(quantity * unit_price, 2)


def revalidate(
    invoice_id: str,
    field: str,
    corrected_value: str,
    author: str,
) -> dict[str, Any]:
    if field not in HEADER_FIELDS and not LINE_FIELD.fullmatch(field):
        raise ValueError("Correction field is not supported")
    if not author.strip():
        raise ValueError("Correction author is required")
    record = get_invoice(invoice_id)
    if record is None:
        raise LookupError("Invoice not found")
    original = copy.deepcopy(record.get("current_data") or record.get("extracted_raw") or {})
    if isinstance(original, str):
        import json

        original = json.loads(original)
    old_value = _current_value(original, field)
    _apply_one(original, field, corrected_value)
    discrepancies, recommendation, status = run_validations(original)
    save_result(
        invoice_id,
        original,
        discrepancies,
        recommendation,
        status,
        initial=False,
        feedback=(
            field,
            None if old_value is None else str(old_value),
            corrected_value,
            author.strip(),
        ),
    )
    report = build_report(
        invoice_id,
        original,
        discrepancies,
        recommendation,
        status,
    )
    write_reports(report)
    index_invoice(
        invoice_id,
        record.get("raw_extracted_text") or "",
        original,
        report,
    )
    return {
        "invoice_id": invoice_id,
        "recommendation": recommendation,
        "validation_status": status,
        "discrepancies_count": len(discrepancies),
        "feedback_history": list_feedback(invoice_id),
    }
