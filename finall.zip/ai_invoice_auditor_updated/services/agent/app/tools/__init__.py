"""MCP tools exposed to cooperating invoice agents."""
