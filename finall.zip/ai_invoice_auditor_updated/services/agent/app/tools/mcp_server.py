from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from app.audit_store import find_invoice_by_number, list_invoices
from app.erp_client import ERPClient

mcp = FastMCP(
    "invoice-auditor-tools",
    instructions="Use these tools for authoritative invoice audit and Mock ERP data.",
)


@mcp.tool()
def lookup_purchase_order(po_number: str) -> dict:
    """Fetch a purchase order and its line items from the Mock ERP HTTP API."""
    result = ERPClient().get_po(po_number)
    return result or {"found": False, "po_number": po_number}


@mcp.tool()
def lookup_vendor(vendor_id: str) -> dict:
    """Fetch a vendor master record from the Mock ERP HTTP API."""
    result = ERPClient().get_vendor(vendor_id)
    return result or {"found": False, "vendor_id": vendor_id}


@mcp.tool()
def lookup_vendor_by_name(vendor_name: str) -> dict:
    """Find an exact case-insensitive vendor name in Mock ERP."""
    result = ERPClient().get_vendor_by_name(vendor_name)
    return result or {"found": False, "vendor_name": vendor_name}


@mcp.tool()
def lookup_sku(item_code: str) -> dict:
    """Fetch an SKU and its tax rate from the Mock ERP HTTP API."""
    result = ERPClient().get_sku(item_code)
    return result or {"found": False, "item_code": item_code}


@mcp.tool()
def get_invoice_audit(invoice_id: str) -> dict:
    """Read an invoice's durable audit record by ID."""
    from app.audit_store import get_invoice

    record = get_invoice(invoice_id)
    if record is None:
        raise ValueError(f"Invoice {invoice_id} was not found")
    return record


@mcp.tool()
def find_invoice_audit(invoice_number: str) -> dict:
    """Find the latest durable audit record for an invoice number."""
    record = find_invoice_by_number(invoice_number)
    if record is None:
        raise ValueError(f"Invoice {invoice_number} was not found")
    return record


@mcp.tool()
def list_recent_invoice_audits(limit: int = 20) -> list[dict]:
    """List recent durable invoice audit records."""
    return list_invoices(max(1, min(limit, 100)))


if __name__ == "__main__":
    mcp.run()
