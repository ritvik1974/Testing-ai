from __future__ import annotations

from typing import Any

from app.agents.business_validation import recommendation_for, run_business_validation
from app.agents.data_validation import validate_completeness


def run_validations(
    data: dict[str, Any],
) -> tuple[list[dict[str, Any]], str, str]:
    discrepancies = validate_completeness(data)
    discrepancies.extend(run_business_validation(data))
    recommendation, status = recommendation_for(data, discrepancies)
    return discrepancies, recommendation, status


def validate_invoice(invoice: dict[str, Any]) -> dict[str, Any]:
    discrepancies = validate_completeness(invoice)
    missing_header = [
        item["field_name"]
        for item in discrepancies
        if item["field_name"] in {
            "invoice_no",
            "invoice_date",
            "vendor_id",
            "currency",
            "total_amount",
        }
        and item["invoice_value"] == "MISSING"
    ]
    return {
        "valid": not discrepancies,
        "issues": [item["field_name"] for item in discrepancies],
        "discrepancies": discrepancies,
        "header_missing": missing_header,
        "currency": invoice.get("currency"),
        "line_missing": [
            {
                "index": index,
                "fields": [
                    item["field_name"].split(".", 1)[1]
                    for item in discrepancies
                    if item["field_name"].startswith(f"line_{index + 1}.")
                    and item["invoice_value"] == "MISSING"
                ],
            }
            for index in range(len(invoice.get("line_items") or []))
        ],
    }
