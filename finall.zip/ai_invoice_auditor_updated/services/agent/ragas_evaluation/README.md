# Ragas evaluation

This package contains a minimal evaluation dataset and runner for invoice audit quality checks.
