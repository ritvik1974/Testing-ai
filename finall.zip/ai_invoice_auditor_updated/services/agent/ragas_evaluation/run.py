from __future__ import annotations

import json
from pathlib import Path
from statistics import mean
from typing import Any

from app.rag.graph import run_candidate

DATASET_PATH = Path(__file__).with_name("dataset.jsonl")


def load_dataset(path: str | Path = DATASET_PATH) -> list[dict[str, Any]]:
    records = []
    for line_number, line in enumerate(
        Path(path).read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid evaluation JSON at line {line_number}") from exc
        if not isinstance(record, dict) or not record.get("question"):
            raise ValueError(f"Evaluation record at line {line_number} has no question")
        records.append(record)
    return records


def evaluate(path: str | Path = DATASET_PATH) -> dict[str, Any]:
    records = load_dataset(path)
    results = []
    for record in records:
        candidate = run_candidate(
            str(record["question"]),
            str(record["invoice_id"]) if record.get("invoice_id") else None,
        )
        results.append(
            {
                "question": record["question"],
                "passed": candidate["passed"],
                "triad": candidate["triad"],
                "answer": candidate["answer"],
                "ground_truth": record.get("ground_truth"),
            }
        )
    metric_names = (
        "context_relevance",
        "groundedness",
        "answer_relevance",
        "average_score",
    )
    metrics = {
        metric: round(
            mean(
                float(item["triad"].get(metric, 0))
                for item in results
            ),
            4,
        )
        if results
        else 0.0
        for metric in metric_names
    }
    return {"count": len(results), "metrics": metrics, "results": results}


if __name__ == "__main__":
    print(json.dumps(evaluate(), ensure_ascii=False, indent=2))
