from __future__ import annotations

import os
import unittest
from unittest.mock import patch

from app.agents.invoice_extraction import (
    _parse_number,
    extract_invoice,
    extract_invoice_fields,
)


class InvoiceExtractionTests(unittest.TestCase):
    def test_parse_number_supports_common_locale_separators(self) -> None:
        self.assertEqual(_parse_number("1,234.56"), 1234.56)
        self.assertEqual(_parse_number("1.234,56"), 1234.56)
        self.assertEqual(_parse_number("42,50"), 42.5)

    def test_extracts_invoice_header_and_line_item(self) -> None:
        raw_text = (
            "Invoice No: INV-EN-001\n"
            "Invoice Date: 2025-02-01\n"
            "Vendor ID: VEND-001\n"
            "Vendor Name: Example Corp\n"
            "PO Number: PO-1001\n"
            "Currency: USD\n"
            "Total: USD 1,500.00\n"
            "Tax: USD 100.00\n"
            "SKU-001 Widget part 2 50.00 100.00\n"
        )

        invoice = extract_invoice_fields(raw_text)

        self.assertEqual(invoice["invoice_no"], "INV-EN-001")
        self.assertEqual(invoice["invoice_date"], "2025-02-01")
        self.assertEqual(invoice["vendor_id"], "VEND-001")
        self.assertEqual(invoice["po_number"], "PO-1001")
        self.assertEqual(invoice["currency"], "USD")
        self.assertEqual(invoice["total_amount"], 1500.0)
        self.assertEqual(invoice["line_items"][0]["total"], 100.0)

    def test_offline_extraction_retains_text_without_claiming_translation(self) -> None:
        raw_text = "Invoice No: INV-EN-001\nTotal: 10.00"
        with patch.dict(os.environ, {"LLM_ENABLED": "false"}):
            invoice = extract_invoice(raw_text)

        self.assertEqual(invoice["translated_text"], raw_text)
        self.assertEqual(invoice["translation_confidence"], 0.0)
        self.assertIn("without machine translation", invoice["translation_note"])


if __name__ == "__main__":
    unittest.main()
