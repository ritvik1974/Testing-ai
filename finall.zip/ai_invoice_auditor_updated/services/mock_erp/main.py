from __future__ import annotations

import json
import os
from contextlib import asynccontextmanager
from pathlib import Path

import psycopg
from fastapi import FastAPI, HTTPException
from psycopg.rows import dict_row

DATABASE_URL = os.environ["DATABASE_URL"]
DATA_DIR = Path(os.getenv("ERP_DATA_DIR", "/data/ERP_mockdata"))


def connect():
    return psycopg.connect(
        DATABASE_URL,
        row_factory=dict_row,
        connect_timeout=5,
    )


def load_json(name: str):
    with (DATA_DIR / name).open(encoding="utf-8") as source:
        return json.load(source)


def seed_master_data() -> None:
    with connect() as conn:
        with conn.cursor() as cursor:
            for vendor in load_json("vendors.json"):
                cursor.execute(
                    """
                    INSERT INTO erp.vendors (vendor_id, vendor_name, country, currency)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (vendor_id) DO UPDATE SET
                        vendor_name = EXCLUDED.vendor_name,
                        country = EXCLUDED.country,
                        currency = EXCLUDED.currency
                    """,
                    (
                        vendor["vendor_id"],
                        vendor["vendor_name"],
                        vendor.get("country"),
                        vendor.get("currency"),
                    ),
                )
            for sku in load_json("sku_master.json"):
                cursor.execute(
                    """
                    INSERT INTO erp.sku_master (item_code, category, uom, gst_rate)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (item_code) DO UPDATE SET
                        category = EXCLUDED.category,
                        uom = EXCLUDED.uom,
                        gst_rate = EXCLUDED.gst_rate
                    """,
                    (
                        sku["item_code"],
                        sku.get("category"),
                        sku.get("uom"),
                        sku.get("gst_rate", 0),
                    ),
                )
            for po in load_json("PO Records.json"):
                cursor.execute(
                    """
                    INSERT INTO erp.purchase_orders (po_number, vendor_id)
                    VALUES (%s, %s)
                    ON CONFLICT (po_number) DO UPDATE SET vendor_id = EXCLUDED.vendor_id
                    """,
                    (po["po_number"], po["vendor_id"]),
                )
                for item in po.get("line_items", []):
                    cursor.execute(
                        """
                        INSERT INTO erp.po_line_items
                            (po_number, item_code, description, qty, unit_price, currency)
                        VALUES (%s, %s, %s, %s, %s, %s)
                        ON CONFLICT (po_number, item_code) DO UPDATE SET
                            description = EXCLUDED.description,
                            qty = EXCLUDED.qty,
                            unit_price = EXCLUDED.unit_price,
                            currency = EXCLUDED.currency
                        """,
                        (
                            po["po_number"],
                            item["item_code"],
                            item.get("description"),
                            item["qty"],
                            item["unit_price"],
                            item["currency"],
                        ),
                    )


@asynccontextmanager
async def lifespan(_: FastAPI):
    seed_master_data()
    yield


app = FastAPI(title="AI Invoice Auditor Mock ERP", lifespan=lifespan)


@app.get("/health/live")
def live() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/health/ready")
def ready() -> dict[str, str]:
    try:
        with connect() as conn:
            conn.execute("SELECT 1")
    except psycopg.Error as exc:
        raise HTTPException(status_code=503, detail="ERP database is unavailable") from exc
    return {"status": "ready", "service": "mock-erp"}


@app.get("/vendor/{vendor_id}")
def get_vendor(vendor_id: str) -> dict:
    with connect() as conn:
        row = conn.execute(
            "SELECT vendor_id, vendor_name, country, currency FROM erp.vendors WHERE vendor_id = %s",
            (vendor_id,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Vendor not found")
    return row


@app.get("/vendor/name/{vendor_name:path}")
def get_vendor_by_name(vendor_name: str) -> dict:
    with connect() as conn:
        row = conn.execute(
            "SELECT vendor_id, vendor_name, country, currency FROM erp.vendors WHERE LOWER(vendor_name) = LOWER(%s)",
            (vendor_name,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Vendor not found")
    return row


@app.get("/sku/{sku_code}")
def get_sku(sku_code: str) -> dict:
    with connect() as conn:
        row = conn.execute(
            "SELECT item_code, category, uom, gst_rate FROM erp.sku_master WHERE item_code = %s",
            (sku_code,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="SKU not found")
    return row


@app.get("/po/{po_number}")
def get_po(po_number: str) -> dict:
    with connect() as conn:
        po = conn.execute(
            "SELECT po_number, vendor_id FROM erp.purchase_orders WHERE po_number = %s",
            (po_number,),
        ).fetchone()
        if po is None:
            raise HTTPException(status_code=404, detail="Purchase order not found")
        po["line_items"] = conn.execute(
            """
            SELECT item_code, description, qty, unit_price, currency
            FROM erp.po_line_items
            WHERE po_number = %s
            ORDER BY id
            """,
            (po_number,),
        ).fetchall()
    return po
