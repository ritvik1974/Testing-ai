from __future__ import annotations

import requests
import streamlit as st
import psycopg

from ui.api import get_health, upload_invoice
from ui.data import (
    invalidate_invoice_cache,
    invoice_summary_frame,
    load_invoices,
)

st.set_page_config(
    page_title="AI Invoice Auditor",
    page_icon="🧾",
    layout="wide",
)

st.title("AI Invoice Auditor")
st.caption("Multilingual invoice intake, ERP validation, and human review")

with st.sidebar:
    st.header("Navigation")
    st.page_link("app.py", label="Overview")
    st.page_link("pages/invoices.py", label="Invoices")
    st.page_link("pages/invoice_review.py", label="Review & corrections")
    st.page_link("pages/assistant.py", label="Invoice assistant")

try:
    health = get_health()
    st.success(f"Agent service: {health.get('status', 'ready')}")
except requests.RequestException as exc:
    st.error(f"Agent API is unavailable: {exc}")
    st.stop()

try:
    invoices = load_invoices()
except psycopg.Error as exc:
    st.error(f"Unable to load invoice audit records: {exc}")
    st.stop()

metrics = st.columns(4)
overview = {
    "total": len(invoices),
    "approved": sum(row.get("recommendation") == "approved" for row in invoices),
    "manual_review": sum(
        row.get("recommendation") == "manual_review" for row in invoices
    ),
    "rejected": sum(row.get("recommendation") == "rejected" for row in invoices),
}
for column, label, key in zip(
    metrics,
    ("Invoices", "Approved", "Manual review", "Rejected"),
    ("total", "approved", "manual_review", "rejected"),
):
    column.metric(label, overview.get(key, 0))

st.subheader("Add invoices")
uploads = st.file_uploader(
    "Upload PDF, DOCX, or PNG files (maximum 25 MB each)",
    type=["pdf", "docx", "png"],
    accept_multiple_files=True,
)
if st.button("Add to incoming queue", disabled=not uploads, type="primary"):
    for uploaded in uploads or []:
        try:
            result = upload_invoice(uploaded.name, uploaded.getvalue())
            if result.get("status") == "duplicate":
                st.info(f"{uploaded.name} was already audited.")
            else:
                st.success(f"{uploaded.name} was queued for processing.")
        except requests.RequestException as exc:
            st.error(f"Could not upload {uploaded.name}: {exc}")
    invalidate_invoice_cache()

st.subheader("Recent audit records")
if invoices:
    st.dataframe(
        invoice_summary_frame(invoices[:10]),
        use_container_width=True,
        hide_index=True,
    )
else:
    st.info("No invoice audit records yet. Upload a file or place one in data/incoming.")

if st.button("Refresh records"):
    invalidate_invoice_cache()
    st.rerun()

st.divider()
st.caption(
    "Original files and reports use the mounted data volume. PostgreSQL is the audit "
    "system of record; Qdrant is a rebuildable search index; Redis is disposable."
)
