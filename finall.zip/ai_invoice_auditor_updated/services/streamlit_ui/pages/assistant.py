from __future__ import annotations

import requests
import streamlit as st

from ui.api import ask_agent
from ui.data import invoice_options, load_invoices

st.set_page_config(page_title="Assistant · AI Invoice Auditor", layout="wide")
st.title("Invoice assistant")
st.caption("Answers are returned only when the evidence confidence gate passes.")

try:
    invoices = load_invoices()
except requests.RequestException as exc:
    st.error(f"Could not load invoice scope options: {exc}")
    st.stop()

scopes = {"All indexed invoices": None, **invoice_options(invoices)}
scope_label = st.selectbox("Search scope", list(scopes))
scope_id = scopes[scope_label]
question = st.text_area(
    "Ask about an invoice, purchase order, or audit finding",
    placeholder="Why was invoice INV-EN-001 sent for manual review?",
    max_chars=4000,
)

if st.button("Ask", type="primary", disabled=not question.strip()):
    try:
        with st.spinner("Retrieving and checking invoice evidence..."):
            result = ask_agent(question.strip(), scope_id)
        if result.get("passed") and result.get("answer"):
            st.markdown(result["answer"])
            triad = result.get("triad") or {}
            score_columns = st.columns(4)
            for column, key, label in zip(
                score_columns,
                (
                    "context_relevance",
                    "groundedness",
                    "answer_relevance",
                    "average_score",
                ),
                ("Context relevance", "Groundedness", "Answer relevance", "Average"),
            ):
                if key in triad:
                    column.metric(label, f"{float(triad[key]):.2f}")
        else:
            st.warning(
                result.get("message")
                or "The answer did not pass the evidence confidence threshold."
            )
        contexts = result.get("contexts") or []
        if contexts:
            with st.expander("View supporting evidence"):
                for evidence in contexts:
                    st.markdown(evidence)
                    st.divider()
    except requests.RequestException as exc:
        st.error(f"Invoice assistant request failed: {exc}")
