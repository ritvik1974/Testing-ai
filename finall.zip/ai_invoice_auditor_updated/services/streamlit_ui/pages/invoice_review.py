from __future__ import annotations

import requests
import streamlit as st
import psycopg

from ui.api import submit_correction
from ui.data import (
    get_feedback,
    get_invoice,
    invalidate_invoice_cache,
    invoice_options,
    load_invoices,
)

st.set_page_config(page_title="Review · AI Invoice Auditor", layout="wide")
st.title("Invoice review")
st.caption("Review extracted fields, current discrepancies, and immutable correction history.")

try:
    invoices = load_invoices()
except (requests.RequestException, psycopg.Error) as exc:
    st.error(f"Could not load invoices: {exc}")
    st.stop()

if not invoices:
    st.info("No audit records are available for review.")
    st.stop()

options = invoice_options(invoices)
selected_label = st.selectbox("Select invoice", list(options))
invoice_id = options[selected_label]
try:
    invoice = get_invoice(invoice_id)
except (requests.RequestException, psycopg.Error, LookupError) as exc:
    st.error(f"Could not load the selected invoice: {exc}")
    st.stop()

data = invoice.get("current_data") or invoice.get("extracted_raw") or {}
if isinstance(data, str):
    st.error("The stored invoice payload is not valid JSON.")
    st.stop()

profile, details = st.columns([1, 1.5])
profile.metric("Recommendation", invoice.get("recommendation") or "pending")
profile.write(f"**Validation status:** {invoice.get('validation_status')}")
profile.write(f"**Invoice:** {invoice.get('invoice_number') or 'Not identified'}")
profile.write(f"**Vendor:** {invoice.get('vendor_name') or invoice.get('vendor_id') or 'Unknown'}")
profile.write(f"**Purchase order:** {invoice.get('po_number') or 'Not identified'}")
profile.write(f"**Source language:** {invoice.get('source_language') or 'Unknown'}")
confidence = invoice.get("translation_confidence")
profile.write(
    f"**Translation confidence:** {float(confidence):.0%}"
    if confidence is not None
    else "**Translation confidence:** Not available"
)

with details:
    st.subheader("Line items")
    st.dataframe(data.get("line_items") or [], use_container_width=True, hide_index=True)

st.subheader("Current discrepancies")
discrepancies = invoice.get("discrepancies") or []
if discrepancies:
    st.dataframe(discrepancies, use_container_width=True, hide_index=True)
else:
    st.success("No current discrepancies.")

st.subheader("Correct an extracted value")
field_options = {
    "Invoice number": "invoice_no",
    "Invoice date": "invoice_date",
    "Vendor ID": "vendor_id",
    "Vendor name": "vendor_name",
    "Purchase order": "po_number",
    "Currency": "currency",
    "Invoice total": "total_amount",
    "Tax amount": "tax_amount",
}
for index, item in enumerate(data.get("line_items") or [], start=1):
    field_options[f"Line {index} · item code"] = f"line_{index}.item_code"
    field_options[f"Line {index} · description"] = f"line_{index}.description"
    field_options[f"Line {index} · quantity"] = f"line_{index}.qty"
    field_options[f"Line {index} · unit price"] = f"line_{index}.unit_price"
    field_options[f"Line {index} · total"] = f"line_{index}.total"

with st.form("invoice-correction"):
    label = st.selectbox("Field to correct", list(field_options))
    correction_value = st.text_input("Correct value")
    author = st.text_input("Auditor name", value="auditor")
    submitted = st.form_submit_button("Save correction and revalidate", type="primary")

if submitted:
    if not correction_value.strip():
        st.error("Enter a correction value.")
    else:
        try:
            result = submit_correction(
                invoice_id,
                field_options[label],
                correction_value,
                author,
            )
            invalidate_invoice_cache()
            st.success(
                f"Correction saved. New recommendation: {result['recommendation']}."
            )
            st.rerun()
        except psycopg.Error as exc:
            st.error(f"Correction could not be saved: {exc}")

with st.expander("Original extraction and report"):
    st.json(invoice.get("extracted_raw") or {})
    if invoice.get("report"):
        st.json(invoice["report"])

with st.expander("Correction history"):
    try:
        history = get_feedback(invoice_id)
        st.dataframe(history, use_container_width=True, hide_index=True)
    except requests.RequestException as exc:
        st.error(f"Could not load correction history: {exc}")
