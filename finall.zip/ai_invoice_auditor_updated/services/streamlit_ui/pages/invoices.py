from __future__ import annotations

import requests
import streamlit as st
import psycopg

from ui.data import invoice_summary_frame, load_invoices

st.set_page_config(page_title="Invoices · AI Invoice Auditor", layout="wide")
st.title("Invoices")
st.caption("Durable audit records and validation outcomes")

try:
    invoices = load_invoices()
except (requests.RequestException, psycopg.Error) as exc:
    st.error(f"Could not load invoices: {exc}")
    st.stop()

if not invoices:
    st.info("No invoices have been processed yet.")
    st.stop()

decisions = ["All"] + sorted(
    {str(row.get("recommendation") or "pending") for row in invoices}
)
selected_decision = st.selectbox("Filter by recommendation", decisions)
filtered = (
    invoices
    if selected_decision == "All"
    else [row for row in invoices if row.get("recommendation") == selected_decision]
)
st.dataframe(invoice_summary_frame(filtered), use_container_width=True, hide_index=True)
