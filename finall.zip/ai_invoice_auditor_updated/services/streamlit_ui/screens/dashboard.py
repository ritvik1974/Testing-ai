from __future__ import annotations

import streamlit as st

st.title("Dashboard")
st.caption("Invoice operations overview")
