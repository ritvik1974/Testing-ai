from __future__ import annotations

import os
from typing import Any

import requests

API_URL = os.getenv("AGENT_API_URL", "http://localhost:8000").rstrip("/")
TIMEOUT = (3.0, 30.0)


def _request(method: str, path: str, **kwargs: Any) -> Any:
    response = requests.request(
        method,
        f"{API_URL}{path}",
        timeout=kwargs.pop("timeout", TIMEOUT),
        **kwargs,
    )
    response.raise_for_status()
    return response.json() if response.content else {}


def get_health() -> dict[str, Any]:
    return _request("GET", "/health/ready")


def get_dashboard() -> dict[str, Any]:
    return _request("GET", "/api/dashboard")


def get_invoices(limit: int = 200) -> list[dict[str, Any]]:
    return _request("GET", "/api/invoices", params={"limit": limit})


def get_invoice(invoice_id: str) -> dict[str, Any]:
    return _request("GET", f"/api/invoices/{invoice_id}")


def get_feedback(invoice_id: str) -> list[dict[str, Any]]:
    return _request("GET", f"/api/invoices/{invoice_id}/feedback")


def submit_correction(
    invoice_id: str,
    field: str,
    corrected_value: str,
    corrected_by: str,
) -> dict[str, Any]:
    return _request(
        "POST",
        f"/api/invoices/{invoice_id}/corrections",
        json={
            "field": field,
            "corrected_value": corrected_value,
            "corrected_by": corrected_by,
        },
    )


def ask_agent(question: str, invoice_id: str | None = None) -> dict[str, Any]:
    return _request(
        "POST",
        "/api/rag/query",
        json={"question": question, "invoice_id": invoice_id},
        timeout=(3.0, 90.0),
    )


def upload_invoice(file_name: str, content: bytes) -> dict[str, Any]:
    return _request(
        "POST",
        "/api/invoices/upload",
        files={"file": (file_name, content)},
    )


def run_ragas_evaluation() -> dict[str, Any]:
    return _request("POST", "/api/evaluation/rag")
