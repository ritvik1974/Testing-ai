from __future__ import annotations

import streamlit as st


def render_status_badge(label: str, color: str = "gray") -> None:
    st.markdown(f'<span style="color:{color}; font-weight:600;">{label}</span>', unsafe_allow_html=True)
