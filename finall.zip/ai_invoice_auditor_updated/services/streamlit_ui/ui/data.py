from __future__ import annotations

import os
from typing import Any

import pandas as pd
import psycopg
import streamlit as st
from psycopg.rows import dict_row

DATABASE_URL = os.getenv(
    "UI_DATABASE_URL",
    "postgresql://invoice_reader:invoice_reader@localhost:5432/invoice_auditor",
)


def _read(query: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
    with psycopg.connect(DATABASE_URL, row_factory=dict_row) as connection:
        return list(connection.execute(query, params).fetchall())


@st.cache_data(ttl=10, show_spinner=False)
def load_invoices() -> list[dict[str, Any]]:
    return _read(
        """
        SELECT a.*,
               COALESCE((
                   SELECT jsonb_agg(to_jsonb(li) - 'invoice_id' ORDER BY li.line_number)
                   FROM audit.invoice_line_items AS li
                   WHERE li.invoice_id = a.invoice_id
               ), '[]'::jsonb) AS line_items,
               COALESCE((
                   SELECT jsonb_agg(to_jsonb(d) - 'invoice_id' ORDER BY d.detected_at)
                   FROM audit.discrepancies AS d
                   WHERE d.invoice_id = a.invoice_id AND d.is_current
               ), '[]'::jsonb) AS discrepancies
        FROM audit.invoice_audit AS a
        ORDER BY a.created_at DESC
        LIMIT 200
        """
    )


def get_invoice(invoice_id: str) -> dict[str, Any]:
    records = _read(
        """
        SELECT a.*,
               COALESCE((
                   SELECT jsonb_agg(to_jsonb(li) - 'invoice_id' ORDER BY li.line_number)
                   FROM audit.invoice_line_items AS li
                   WHERE li.invoice_id = a.invoice_id
               ), '[]'::jsonb) AS line_items,
               COALESCE((
                   SELECT jsonb_agg(to_jsonb(d) - 'invoice_id' ORDER BY d.detected_at)
                   FROM audit.discrepancies AS d
                   WHERE d.invoice_id = a.invoice_id AND d.is_current
               ), '[]'::jsonb) AS discrepancies
        FROM audit.invoice_audit AS a
        WHERE a.invoice_id = %s::uuid
        """,
        (invoice_id,),
    )
    if not records:
        raise LookupError(f"Invoice {invoice_id} was not found.")
    return records[0]


def get_feedback(invoice_id: str) -> list[dict[str, Any]]:
    return _read(
        """
        SELECT field_name, original_value, corrected_value, corrected_by,
               corrected_at, revalidated
        FROM audit.human_feedback
        WHERE invoice_id = %s::uuid
        ORDER BY corrected_at DESC
        """,
        (invoice_id,),
    )


def invalidate_invoice_cache() -> None:
    load_invoices.clear()


def invoice_options(invoices: list[dict[str, Any]]) -> dict[str, str]:
    options = {}
    for invoice in invoices:
        invoice_id = str(invoice["invoice_id"])
        number = invoice.get("invoice_number") or "Invoice pending"
        vendor = invoice.get("vendor_name") or invoice.get("vendor_id") or "Unknown vendor"
        options[f"{number} · {vendor} · {invoice_id[:8]}"] = invoice_id
    return options


def invoice_summary_frame(invoices: list[dict[str, Any]]) -> pd.DataFrame:
    rows = [
        {
            "Invoice": invoice.get("invoice_number") or "Pending",
            "Vendor": invoice.get("vendor_name") or invoice.get("vendor_id") or "Unknown",
            "PO": invoice.get("po_number") or "—",
            "Date": invoice.get("invoice_date") or "—",
            "Total": invoice.get("total_amount"),
            "Currency": invoice.get("currency") or "—",
            "Decision": invoice.get("recommendation") or "pending",
            "Status": invoice.get("validation_status") or "processing",
        }
        for invoice in invoices
    ]
    return pd.DataFrame(rows)


def normalize_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return rows
