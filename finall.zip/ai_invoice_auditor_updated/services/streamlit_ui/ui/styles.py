from __future__ import annotations


def app_css() -> str:
    return """
    <style>
        .stApp { background-color: #f5f7fb; }
    </style>
    """
