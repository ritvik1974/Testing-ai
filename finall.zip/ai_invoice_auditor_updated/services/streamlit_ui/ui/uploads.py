from __future__ import annotations

from pathlib import Path


def save_uploaded_file(uploaded_file, destination_dir: str | Path) -> str:
    path = Path(destination_dir)
    path.mkdir(parents=True, exist_ok=True)
    out = path / uploaded_file.name
    with open(out, "wb") as fh:
        fh.write(uploaded_file.getvalue())
    return str(out)
